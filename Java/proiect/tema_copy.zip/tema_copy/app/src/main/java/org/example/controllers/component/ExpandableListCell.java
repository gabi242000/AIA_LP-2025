package org.example.controllers.component;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class ExpandableListCell extends ListCell<DayGroup> {
    
    private final VBox container;
    private final HBox headerRow;
    private final Button expandBtn;
    private final Label dateLabel;
    private final Label fileLabel;
    private final Label countLabel;
    private final VBox expandedContent;
    private final ListView<DayGroup> parentListView;

    public ExpandableListCell(ListView<DayGroup> parentListView) {
        this.parentListView = parentListView;
        
        container = new VBox(5);
        container.setPadding(new Insets(8, 10, 8, 8)); // Added extra right padding for expand button
        // Green accent theme
        container.setStyle("-fx-background-color: #1e3d2f; -fx-background-radius: 5; -fx-border-color: #2d5a44; -fx-border-radius: 5;");
        
        headerRow = new HBox(10);
        headerRow.setAlignment(Pos.CENTER_LEFT);
        headerRow.setPadding(new Insets(0, 2, 0, 2)); // 2px padding left for text, 2px right for button
        
        expandBtn = new Button("+");
        expandBtn.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-min-width: 25px; -fx-min-height: 25px; -fx-cursor: hand; -fx-background-color: #2d5a44; -fx-text-fill: #ffffff;");
        expandBtn.setOnAction(e -> toggleExpand());
        
        dateLabel = new Label();
        dateLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #88aa99;");
        
        fileLabel = new Label();
        fileLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #ffffff;");
        HBox.setHgrow(fileLabel, Priority.ALWAYS);
        
        countLabel = new Label();
        countLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #ccddcc; -fx-padding: 2 6; -fx-background-color: #2d5a44; -fx-background-radius: 10;");
        
        expandedContent = new VBox(3);
        expandedContent.setPadding(new Insets(5, 0, 0, 10));
        expandedContent.setStyle("-fx-border-color: #2d5a44; -fx-border-width: 1 0 0 0;");
        
        VBox headerContainer = new VBox(2);
        headerContainer.getChildren().addAll(fileLabel, dateLabel);
        HBox.setHgrow(headerContainer, Priority.ALWAYS);
        
        // Button moved to the RIGHT side (after countLabel)
        headerRow.getChildren().addAll(headerContainer, countLabel, expandBtn);
        container.getChildren().add(headerRow);
    }

    @Override
    protected void updateItem(DayGroup item, boolean empty) {
        super.updateItem(item, empty);
        
        if (empty || item == null) {
            setGraphic(null);
            setText(null);
        } else {
            fileLabel.setText(item.getFirstFile());
            dateLabel.setText(item.getDate());
            
            if (item.hasMultipleFiles()) {
                countLabel.setText("+" + (item.getFileCount() - 1) + " more");
                countLabel.setVisible(true);
                expandBtn.setVisible(true);
                expandBtn.setText(item.isExpanded() ? "−" : "+");
                
                // Update expanded content
                expandedContent.getChildren().clear();
                if (item.isExpanded()) {
                    for (int i = 1; i < item.getFiles().size(); i++) {
                        Label fileItem = new Label("• " + item.getFiles().get(i));
                        fileItem.setStyle("-fx-font-size: 13px; -fx-padding: 3 0; -fx-text-fill: #cccccc;");
                        expandedContent.getChildren().add(fileItem);
                    }
                    if (!container.getChildren().contains(expandedContent)) {
                        container.getChildren().add(expandedContent);
                    }
                    countLabel.setVisible(false);
                } else {
                    container.getChildren().remove(expandedContent);
                    countLabel.setVisible(true);
                }
            } else {
                countLabel.setVisible(false);
                expandBtn.setVisible(false);
                container.getChildren().remove(expandedContent);
            }
            
            setGraphic(container);
            setText(null);
        }
    }

    private void toggleExpand() {
        DayGroup item = getItem();
        if (item != null && item.hasMultipleFiles()) {
            item.setExpanded(!item.isExpanded());
            // Refresh the cell
            updateItem(item, false);
            // Force ListView to recalculate heights
            parentListView.refresh();
        }
    }
}