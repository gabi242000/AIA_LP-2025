package org.example.controllers;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Pos;
import java.util.Optional;
import org.example.services.Login;

public class LoginView {
    private final SceneController router;
    private BorderPane viewLayout; 
    private boolean pressed = false;
    
    public LoginView(SceneController router) {
        this.router = router;
        initializeUI();
    }

    public Pane getView() {
        return viewLayout;
    }

    private void initializeUI() {
        // UI initialization code here
        VBox login_form = new VBox(30);
        Button login_button = new Button("Login");
        Button tutorial_button = new Button("Tutorial");
        login_form.getChildren().addAll(login_button, tutorial_button);
        login_form.setAlignment(Pos.CENTER);
        viewLayout = new BorderPane();
        viewLayout.setCenter(login_form);

        //logica butoana , intoarce sa le refaci
        login_button.setOnAction(e -> {
            if(pressed == false && Login.checkGitHubAuthStatus() != 1){
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Login");
                alert.setHeaderText(null);
                alert.setContentText("It is recommended to read the tutorial first if you are a new user!");

                // custom buttons
                ButtonType readTutorial = new ButtonType("Read Tutorial");
                ButtonType skipTutorial = new ButtonType("Skip Tutorial");
                ButtonType cancel = new ButtonType("Cancel" , ButtonType.CANCEL.getButtonData());

                alert.getButtonTypes().setAll(readTutorial, skipTutorial, cancel);
                Optional<ButtonType> result = alert.showAndWait();

                if(result.isPresent()){
                    if (result.get() == readTutorial){
                        //tutorial button
                        System.out.println("Taking you to the tutorial!");
                        tutorial_button.fire();
                        pressed = true;
                    }
                    else if (result.get() == skipTutorial){
                        //attempt login
                        System.out.println("Skipping tutorial, taking you to main view!");
                        Login.startGitHubLogin(success -> {
                            if(success) {
                                router.activate("MAIN");
                            }
                        });
                    }
                    else {
                        // cancell login
                        System.out.println("Login cancelled.");
                    }
                }
            }
            else{
                if(Login.checkGitHubAuthStatus() == 1) {
                    router.activate("MAIN");
                } else {
                Login.startGitHubLogin(success -> {
                    if(success) {
                        router.activate("MAIN");
                    }
                });
                }
                System.out.println("Magic behind the scenes!");
            }
        });

        tutorial_button.setOnAction(e -> {
            //creating a message box
            pressed = true;
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Tutorial");
            alert.setHeaderText(null);
            alert.setContentText("This is a simple tutorial message.");
            alert.showAndWait();
            System.out.println("Taking you to the tutorial!");
        });            

        //styling
        login_button.setPrefWidth(200);
        login_button.setPrefHeight(50);
        tutorial_button.setPrefWidth(200);
        tutorial_button.setPrefHeight(50);

        // Green accent theme styling
        login_form.setStyle("-fx-background-color: #1e1e1e; -fx-padding: 20;");
        login_button.setStyle("-fx-background-color: #2d5a44; -fx-text-fill: #ffffff; -fx-font-size: 16px; -fx-font-weight: bold; -fx-border-color: #3d7a5a; -fx-border-radius: 6; -fx-background-radius: 6;");
        tutorial_button.setStyle("-fx-background-color: #1e3d2f; -fx-text-fill: #88aa99; -fx-font-size: 14px; -fx-border-color: #2d5a44; -fx-border-radius: 6; -fx-background-radius: 6;");
    }
}
