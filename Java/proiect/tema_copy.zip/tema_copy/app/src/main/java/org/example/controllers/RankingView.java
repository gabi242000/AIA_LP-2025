package org.example.controllers;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import org.example.config.AppConfig;
import org.example.services.RankingService;
import org.example.controllers.component.CommitSelectDialog;

import java.util.List;
import java.util.Map;

/**
 * View component showing the leaderboard/rankings.
 * Displays Top 30 users ranked by commit timing points.
 * Supports switching between General (all-time) and Weekly (per-homework) views.
 */
public class RankingView extends VBox {
    
    private final AppConfig appConfig;
    private final RankingService rankingService;
    
    private ListView<RankingEntry> rankingListView;
    private ObservableList<RankingEntry> rankingEntries;
    private ToggleButton generalBtn;
    private ToggleButton weeklyBtn;
    private Button refreshBtn;
    private Label statusLabel;
    private Label homeworkCountLabel;
    private ProgressBar refreshProgressBar;
    
    private String currentHomeworkFile; // Currently selected homework in the file list
    private int currentHomeworkIndex = -1; // Index of current homework in the list
    private int totalHomeworkCount = 0; // Total number of homework files
    private boolean isWeeklyMode = false;
    
    // Callback for when ranking refresh completes
    private Runnable onRefreshComplete;
    
    public RankingView(AppConfig appConfig, RankingService rankingService) {
        this.appConfig = appConfig;
        this.rankingService = rankingService;
        initializeUI();
        loadCachedRankings();
    }
    
    private void initializeUI() {
        setSpacing(10);
        setPadding(new Insets(10));
        setAlignment(Pos.TOP_CENTER);
        setStyle("-fx-background-color: #1a2e24; -fx-border-color: #2d5a44; -fx-border-width: 0 0 0 1;");
        setMinWidth(250);
        setPrefWidth(280);
        
        // Title
        Label titleLabel = new Label("🏆 Leaderboard");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        
        // Toggle buttons for General/Weekly view
        HBox toggleContainer = new HBox(5);
        toggleContainer.setAlignment(Pos.CENTER);
        
        ToggleGroup viewToggle = new ToggleGroup();
        
        generalBtn = new ToggleButton("General");
        generalBtn.setToggleGroup(viewToggle);
        generalBtn.setSelected(true);
        generalBtn.setStyle(getToggleButtonStyle(true));
        generalBtn.setOnAction(e -> {
            isWeeklyMode = false;
            updateToggleStyles();
            loadGeneralRankings();
        });
        
        weeklyBtn = new ToggleButton("This Week");
        weeklyBtn.setToggleGroup(viewToggle);
        weeklyBtn.setStyle(getToggleButtonStyle(false));
        weeklyBtn.setOnAction(e -> {
            isWeeklyMode = true;
            updateToggleStyles();
            loadWeeklyRankings();
        });
        
        toggleContainer.getChildren().addAll(generalBtn, weeklyBtn);
        
        // Refresh button
        HBox refreshContainer = new HBox(10);
        refreshContainer.setAlignment(Pos.CENTER);
        
        refreshBtn = new Button("↻ Refresh");
        refreshBtn.setStyle("-fx-font-size: 12px; -fx-cursor: hand; -fx-background-color: #2d5a44; -fx-text-fill: #4CAF50;");
        refreshBtn.setOnAction(e -> triggerRefresh());
        
        statusLabel = new Label("");
        statusLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #88aa99;");
        
        homeworkCountLabel = new Label("");
        homeworkCountLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #4CAF50; -fx-font-weight: bold;");
        
        refreshContainer.getChildren().addAll(refreshBtn, statusLabel, homeworkCountLabel);
        
        // Progress bar (hidden by default)
        refreshProgressBar = new ProgressBar(0);
        refreshProgressBar.setPrefWidth(200);
        refreshProgressBar.setPrefHeight(8);
        refreshProgressBar.setVisible(false);
        refreshProgressBar.setStyle("-fx-accent: #4CAF50;");
        
        // Rankings list
        rankingEntries = FXCollections.observableArrayList();
        rankingListView = new ListView<>(rankingEntries);
        rankingListView.setCellFactory(lv -> new RankingListCell());
        rankingListView.setStyle("-fx-background-color: #1e3d2f; -fx-border-color: #2d5a44;");
        rankingListView.setPrefHeight(400);
        VBox.setVgrow(rankingListView, Priority.ALWAYS);
        
        // Click handler for selecting a person
        rankingListView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                RankingEntry selected = rankingListView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    handlePersonSelection(selected);
                }
            }
        });
        
        // Help text
        Label helpLabel = new Label("Double-click to copy homework");
        helpLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #668877;");
        
        // Wrap toggle and refresh buttons in VBox with dark background
        VBox buttonWrapper = new VBox(8);
        buttonWrapper.setStyle("-fx-background-color: #0d1a14; -fx-padding: 8; -fx-background-radius: 6;");
        buttonWrapper.setAlignment(Pos.CENTER);
        buttonWrapper.getChildren().addAll(toggleContainer, refreshContainer);
        
        getChildren().addAll(
            titleLabel,
            buttonWrapper,
            refreshProgressBar,
            rankingListView,
            helpLabel
        );
    }
    
    private String getToggleButtonStyle(boolean selected) {
        if (selected) {
            return "-fx-font-size: 11px; -fx-background-color: #4CAF50; -fx-text-fill: white; -fx-cursor: hand;";
        }
        return "-fx-font-size: 11px; -fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;";
    }
    
    private void updateToggleStyles() {
        generalBtn.setStyle(getToggleButtonStyle(!isWeeklyMode));
        weeklyBtn.setStyle(getToggleButtonStyle(isWeeklyMode));
    }
    
    /**
     * Loads cached rankings immediately (non-blocking).
     */
    private void loadCachedRankings() {
        if (rankingService.hasRankingData()) {
            loadGeneralRankings();
            statusLabel.setText("Cached data loaded");
        } else {
            statusLabel.setText("No cached data");
            rankingEntries.clear();
            rankingEntries.add(new RankingEntry("-", "No rankings yet", 0));
        }
    }
    
    /**
     * Loads general (all-time) rankings.
     * If a homework is selected, shows commit indicator for that period.
     */
    private void loadGeneralRankings() {
        rankingEntries.clear();
        
        List<Map.Entry<String, Integer>> topRankings = rankingService.getTopRankings(70);
        
        if (topRankings.isEmpty()) {
            rankingEntries.add(new RankingEntry("-", "No rankings available", 0));
            return;
        }
        
        int rank = 1;
        for (Map.Entry<String, Integer> entry : topRankings) {
            // Check if person has commits in current homework period (if selected)
            Boolean hasCommit = null;
            if (currentHomeworkFile != null && !currentHomeworkFile.isEmpty()) {
                hasCommit = rankingService.hasCommitsInPeriod(currentHomeworkFile, entry.getKey());
            }
            
            rankingEntries.add(new RankingEntry(
                String.valueOf(rank),
                entry.getKey(),
                entry.getValue(),
                hasCommit
            ));
            rank++;
        }
    }
    
    /**
     * Loads weekly rankings for the currently selected homework.
     */
    private void loadWeeklyRankings() {
        rankingEntries.clear();
        
        if (currentHomeworkFile == null || currentHomeworkFile.isEmpty()) {
            rankingEntries.add(new RankingEntry("-", "Select a homework first", 0));
            return;
        }
        
        Map<String, Integer> weeklyRankings = rankingService.getWeeklyRankings(currentHomeworkFile);
        
        if (weeklyRankings.isEmpty()) {
            rankingEntries.add(new RankingEntry("-", "No commits this period", 0));
            return;
        }
        
        int rank = 1;
        for (Map.Entry<String, Integer> entry : weeklyRankings.entrySet()) {
            if (rank > 70) break;
            rankingEntries.add(new RankingEntry(
                String.valueOf(rank),
                entry.getKey(),
                entry.getValue()
            ));
            rank++;
        }
    }
    
    /**
     * Handles when user selects a person to copy from.
     */
    private void handlePersonSelection(RankingEntry entry) {
        String person = entry.name;
        
        if (person.equals("No rankings available") || 
            person.equals("No rankings yet") ||
            person.equals("Select a homework first") ||
            person.equals("No commits this period")) {
            return;
        }
        
        // Check if person has commits in the current period
        if (currentHomeworkFile != null && !currentHomeworkFile.isEmpty()) {
            if (!rankingService.hasCommitsInPeriod(currentHomeworkFile, person)) {
                // Show popup - no commits in this period (default white styling)
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("No Commits");
                alert.setHeaderText(null);
                alert.setContentText(person + " did not submit any commits during this homework period.");
                alert.showAndWait();
                return;
            }
            
            // Show commit selection dialog
            CommitSelectDialog dialog = new CommitSelectDialog(
                rankingService, 
                currentHomeworkFile, 
                person
            );
            dialog.show();
        } else {
            // No homework selected - prompt user (default white styling)
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Select Homework");
            alert.setHeaderText(null);
            alert.setContentText("Please select a homework file from the list first.");
            alert.showAndWait();
        }
    }
    
    /**
     * Triggers an async ranking refresh.
     */
    private void triggerRefresh() {
        refreshBtn.setDisable(true);
        refreshProgressBar.setVisible(true);
        refreshProgressBar.setProgress(0);
        statusLabel.setText("Refreshing...");
        
        rankingService.refreshRankingsAsync(
            // Progress callback
            progress -> Platform.runLater(() -> {
                refreshProgressBar.setProgress(progress);
                statusLabel.setText("Refreshing... " + (int)(progress * 100) + "%");
            }),
            // Completion callback
            () -> Platform.runLater(() -> {
                refreshProgressBar.setVisible(false);
                refreshBtn.setDisable(false);
                statusLabel.setText("Updated");
                
                // Reload the current view
                if (isWeeklyMode) {
                    loadWeeklyRankings();
                } else {
                    loadGeneralRankings();
                }
                
                if (onRefreshComplete != null) {
                    onRefreshComplete.run();
                }
            })
        );
    }
    
    /**
     * Triggers async refresh and updates the given progress bar.
     * Used for initial startup refresh.
     */
    public void triggerRefreshWithExternalProgress(ProgressBar externalProgressBar, Runnable onComplete) {
        refreshBtn.setDisable(true);
        statusLabel.setText("Refreshing...");
        
        rankingService.refreshRankingsAsync(
            // Progress callback - update external progress bar
            progress -> Platform.runLater(() -> {
                if (externalProgressBar != null) {
                    externalProgressBar.setProgress(progress);
                }
                statusLabel.setText("Refreshing... " + (int)(progress * 100) + "%");
            }),
            // Completion callback
            () -> Platform.runLater(() -> {
                refreshBtn.setDisable(false);
                statusLabel.setText("Updated");
                
                // Reload the current view
                if (isWeeklyMode) {
                    loadWeeklyRankings();
                } else {
                    loadGeneralRankings();
                }
                
                if (onComplete != null) {
                    onComplete.run();
                }
            })
        );
    }
    
    /**
     * Sets the currently selected homework file.
     * Called when user selects a file in the left panel.
     */
    public void setCurrentHomework(String homeworkFile) {
        this.currentHomeworkFile = homeworkFile;
        
        // Update homework count label
        updateHomeworkCountLabel();
        
        // Refresh the view to show commit indicators
        if (isWeeklyMode) {
            loadWeeklyRankings();
        } else {
            loadGeneralRankings();
        }
    }
    
    /**
     * Sets the current homework index and total count for display.
     * @param index The 1-based index of the current homework (0 or negative to hide)
     * @param total The total number of homework files
     */
    public void setHomeworkCount(int index, int total) {
        this.currentHomeworkIndex = index;
        this.totalHomeworkCount = total;
        updateHomeworkCountLabel();
    }
    
    /**
     * Sets the total homework count.
     */
    public void setTotalHomeworkCount(int total) {
        this.totalHomeworkCount = total;
        updateHomeworkCountLabel();
    }
    
    /**
     * Updates the homework count label display.
     */
    private void updateHomeworkCountLabel() {
        if (currentHomeworkIndex > 0 && totalHomeworkCount > 0) {
            homeworkCountLabel.setText("(" + currentHomeworkIndex + "/" + totalHomeworkCount + ")");
        } else if (totalHomeworkCount > 0) {
            homeworkCountLabel.setText("-/" + totalHomeworkCount);
        } else {
            homeworkCountLabel.setText("");
        }
    }
    
    /**
     * Sets callback for when refresh completes.
     */
    public void setOnRefreshComplete(Runnable callback) {
        this.onRefreshComplete = callback;
    }
    
    // ==================== Inner Classes ====================
    
    /**
     * Data class for ranking entries.
     */
    public static class RankingEntry {
        public final String rank;
        public final String name;
        public final int points;
        public final Boolean hasCommitInPeriod; // null = unknown, true = has commit, false = no commit
        
        public RankingEntry(String rank, String name, int points) {
            this.rank = rank;
            this.name = name;
            this.points = points;
            this.hasCommitInPeriod = null;
        }
        
        public RankingEntry(String rank, String name, int points, Boolean hasCommitInPeriod) {
            this.rank = rank;
            this.name = name;
            this.points = points;
            this.hasCommitInPeriod = hasCommitInPeriod;
        }
    }
    
    /**
     * Custom cell renderer for ranking entries.
     */
    private static class RankingListCell extends ListCell<RankingEntry> {
        @Override
        protected void updateItem(RankingEntry entry, boolean empty) {
            super.updateItem(entry, empty);
            
            if (empty || entry == null) {
                setGraphic(null);
                setText(null);
                setStyle("-fx-background-color: #1a2e24;");
                return;
            }
            
            HBox container = new HBox(10);
            container.setAlignment(Pos.CENTER_LEFT);
            container.setPadding(new Insets(5, 10, 5, 10));
            
            // Rank badge
            Label rankLabel = new Label(entry.rank);
            rankLabel.setMinWidth(30);
            rankLabel.setAlignment(Pos.CENTER);
            
            // Style based on rank
            String rankStyle = "-fx-font-size: 12px; -fx-font-weight: bold; ";
            if (entry.rank.equals("1")) {
                rankStyle += "-fx-text-fill: #FFD700;"; // Gold
            } else if (entry.rank.equals("2")) {
                rankStyle += "-fx-text-fill: #C0C0C0;"; // Silver
            } else if (entry.rank.equals("3")) {
                rankStyle += "-fx-text-fill: #CD7F32;"; // Bronze
            } else {
                rankStyle += "-fx-text-fill: #88aa99;";
            }
            rankLabel.setStyle(rankStyle);
            
            // Name
            Label nameLabel = new Label(entry.name);
            nameLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #ffffff;");
            HBox.setHgrow(nameLabel, Priority.ALWAYS);
            
            // Points
            Label pointsLabel = new Label(entry.points + " pts");
            pointsLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #4CAF50;");
            
            container.getChildren().addAll(rankLabel, nameLabel, pointsLabel);
            
            // Commit indicator (only shown when homework is selected)
            if (entry.hasCommitInPeriod != null) {
                Label indicatorLabel = new Label(entry.hasCommitInPeriod ? "✔" : "—");
                indicatorLabel.setMinWidth(20);
                indicatorLabel.setAlignment(Pos.CENTER);
                indicatorLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: " + 
                    (entry.hasCommitInPeriod ? "#4CAF50;" : "#ff6b6b;"));
                container.getChildren().add(indicatorLabel);
            }
            
            setGraphic(container);
            setText(null);
            setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        }
    }
}
