package org.example.controllers;

import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.util.HashMap;
import org.example.controllers.component.CustomTitleBar;

public class SceneController {
    private final Stage stage;
    private final Scene scene;
    private final BorderPane rootLayout;
    // Store views so we don't recreate them every time (optional, but good for performance)
    private final HashMap<String, Pane> screenMap = new HashMap<>();

    public SceneController(Stage stage) {
        this.stage = stage;
        this.rootLayout = new BorderPane();
        this.rootLayout.setTop(new CustomTitleBar(stage, "Teme copiinatorul"));
        this.scene = new Scene(rootLayout, 800, 600);///ai putea sa ii faci size dinamic dupa marimea ecranului ca pe 2k arata mai mic
        this.scene.getStylesheets().add(getClass().getResource("/org/example/styles/global.css").toExternalForm());
        this.stage.setScene(this.scene);
    }

    public void addScreen(String name, Pane pane) {
        screenMap.put(name, pane);
    }

    public void activate(String name) {
        Pane pane = screenMap.get(name);
        if (pane != null) {
            rootLayout.setCenter(pane);
        }
    }
    
    public Stage getStage() {
        return stage;
    }
}