package org.example.controllers.component;

import java.util.List;
import java.util.ArrayList;

public class DayGroup {
    private final String date; // formatted date string
    private final List<String> files;
    private boolean expanded;

    public DayGroup(String date) {
        this.date = date;
        this.files = new ArrayList<>();
        this.expanded = false;
    }

    public String getDate() {
        return date;
    }

    public List<String> getFiles() {
        return files;
    }

    public void addFile(String file) {
        files.add(file);
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public String getFirstFile() {
        return files.isEmpty() ? "" : files.get(0);
    }

    public int getFileCount() {
        return files.size();
    }

    public boolean hasMultipleFiles() {
        return files.size() > 1;
    }
}