package org.example.services;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.function.Consumer;
import java.io.BufferedReader;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;

public class Login {
    public static int checkGitHubAuthStatus() {
        try {
            // Return values:
            // 1 = Logged in
            // 0 = Not logged in
            // -1 = gh CLI not installed
            ProcessBuilder processBuilder = new ProcessBuilder("gh", "auth", "status");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            int exitCode = process.waitFor();
            return exitCode == 0 ? 1 : 0;
        } catch (IOException e) {
            return -1; // Not installed or not added to path 
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return -1;
        }
    }
    
    public static String fetchRepoList() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("gh", "api", "/user/repos" , "--paginate" , "-q", ".[].full_name");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            StringBuilder output = new StringBuilder();
            try (var reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            String result = output.toString();            
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                // Successfully fetched repo list
                return result;
            } else {
                // Handle error
                System.out.println("Failed to fetch repository list.");
                return null;
            }
        } catch (IOException | InterruptedException e) {
            // Handle exception
            System.out.println("An error occurred while fetching the repository list.");
            return null;
        }
    }

    public static void notLoggedIn() {
        ///ceva
        System.out.println("You are not logged in to GitHub CLI.");
        System.out.println("Please log in by running 'gh auth login' in your terminal.");
    }


    public static void startGitHubLogin(Consumer<Boolean> callback) {
        // Run in a separate thread to avoid freezing the UI
        new Thread(() -> {
            try {
                ProcessBuilder processBuilder = new ProcessBuilder(
                    "gh", "auth", "login", "-h", "github.com", "-p", "https", "-w"
                );
                // DON'T use inheritIO() - we need to read the output
                processBuilder.redirectErrorStream(true);
                Process process = processBuilder.start();

                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream())
                );

                String code = null;
                String line;
                
                while ((line = reader.readLine()) != null) {
                    System.out.println(line); // Debug output
                    
                    // Look for the one-time code (format: XXXX-XXXX)
                    if (line.matches(".*[A-Z0-9]{4}-[A-Z0-9]{4}.*")) {
                        code = line.trim();
                        break; // Found the code, stop reading
                    }
                }

                final String loginCode = code;
                
                final Alert[] codeAlert = new Alert[1];

                // Show alert on JavaFX thread
                Platform.runLater(() -> {
                    if (loginCode != null) {
                        Clipboard clipboard = Clipboard.getSystemClipboard();
                        ClipboardContent content = new ClipboardContent();
                        // Extract just the code (XXXX-XXXX)
                        String justCode = loginCode.replaceAll(".*([A-Z0-9]{4}-[A-Z0-9]{4}).*", "$1");
                        content.putString(justCode);
                        clipboard.setContent(content);
                    }

                    codeAlert[0] = new Alert(Alert.AlertType.INFORMATION);
                    codeAlert[0].setTitle("GitHub Login");
                    codeAlert[0].setHeaderText("Enter this code in your browser:");
                    codeAlert[0].setContentText((loginCode != null ? loginCode : "Code not found") + "\n\n(The code has been copied to your clipboard.)");
                    codeAlert[0].show(); // Use show() instead of showAndWait() to not block
                });

                // Open browser
                try {
                    if (java.awt.Desktop.isDesktopSupported()) {
                        java.awt.Desktop desktop = java.awt.Desktop.getDesktop();
                        if (desktop.isSupported(java.awt.Desktop.Action.BROWSE)) {
                            desktop.browse(new java.net.URI("https://github.com/login/device"));
                        }
                    }
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("Failed to open browser. Go to https://github.com/login/device manually.");
                        alert.show();
                    });
                }

                // Wait for process to complete
                process.waitFor();
                reader.close();

                boolean loginSuccess = checkGitHubAuthStatus() == 1;

                Platform.runLater(() -> {
                    // Close the code alert
                    if (codeAlert[0] != null) {
                        codeAlert[0].close();
                    }
                    
                    if (loginSuccess) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Login Successful");
                        alert.setHeaderText(null);
                        alert.setContentText("You have successfully logged in to GitHub!");
                        alert.show();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Login Failed");
                        alert.setHeaderText(null);
                        alert.setContentText("Login was not completed. Please try again.");
                        alert.show();
                    }
                });

                if(callback != null) {
                    Platform.runLater(() -> callback.accept(loginSuccess));
                }

            } catch (IOException | InterruptedException e) {
                Platform.runLater(() -> {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText(null);
                    alert.setContentText("An error occurred while trying to log in to GitHub.");
                    alert.show();
                });

                if(callback != null) {
                    Platform.runLater(() -> callback.accept(false));
                }
            }
        }).start();
    }

    public static void startGitHubLogin() {
        startGitHubLogin(null);
    }
    
    /**
     * Logs out from GitHub CLI.
     * @return true if logout was successful, false otherwise
     */
    public static boolean logout() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "auth", "logout", "-h", "github.com"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            // Read output to prevent blocking
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                while (reader.readLine() != null) {
                    // Consume output
                }
            }
            
            int exitCode = process.waitFor();
            return exitCode == 0;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        System.out.println(checkGitHubAuthStatus());
        System.out.println(fetchRepoList());
    }
}
