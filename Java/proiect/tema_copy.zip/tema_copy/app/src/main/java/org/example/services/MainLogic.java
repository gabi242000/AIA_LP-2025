package org.example.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.example.config.AppConfig;

public class MainLogic {
    
    private final AppConfig appConfig;
    
    public MainLogic(AppConfig appConfig) {
        this.appConfig = appConfig;
    }

    /**
     * Fetches folders from the homework folder
     * @return List of folder names in the homework folder
     */
    public List<String> fetchHomeworkFolders() {
        List<String> folders = new ArrayList<>();
        
        String repoName = appConfig.getSelectedRepo();
        String homeworkPath = appConfig.getHomeworkFolderPath();
        
        if (repoName == null || repoName.isEmpty()) {
            return folders;
        }
        
        // Handle root path and remove leading slash
        if (homeworkPath == null || homeworkPath.isEmpty() || homeworkPath.equals("/")) {
            homeworkPath = "";
        } else if (homeworkPath.startsWith("/")) {
            homeworkPath = homeworkPath.substring(1);
        }
        
        try {
            String apiUrl = homeworkPath.isEmpty() 
                ? "repos/" + repoName + "/contents"
                : "repos/" + repoName + "/contents/" + homeworkPath;
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", apiUrl, "--jq", ".[] | select(.type == \"dir\") | .name"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    // Ignore .gitkeep and hidden folders
                    if (!line.isEmpty() && !line.equals(".gitkeep") && !line.startsWith(".")) {
                        folders.add(line);
                    }
                }
            }
            process.waitFor();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return folders;
    }
    
    /**
     * Fetches all items (files and folders) from the homework folder
     * @return List of item names in the homework folder
     */
    public List<String> fetchHomeworkItems() {
        List<String> items = new ArrayList<>();
        
        String repoName = appConfig.getSelectedRepo();
        String homeworkPath = appConfig.getHomeworkFolderPath();
        
        if (repoName == null || repoName.isEmpty()) {
            items.add("Error: No repository selected");
            return items;
        }
        
        // Handle root path and remove leading slash
        if (homeworkPath == null || homeworkPath.isEmpty() || homeworkPath.equals("/")) {
            homeworkPath = "";
        } else if (homeworkPath.startsWith("/")) {
            homeworkPath = homeworkPath.substring(1);
        }
        
        try {
            String apiUrl = homeworkPath.isEmpty() 
                ? "repos/" + repoName + "/contents"
                : "repos/" + repoName + "/contents/" + homeworkPath;
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", apiUrl, "--jq", ".[] | .name"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    // Ignore .gitkeep files
                    if (!line.isEmpty() && !line.equals(".gitkeep")) {
                        items.add(line);
                    }
                }
            }
            process.waitFor();
            
            if (items.isEmpty()) {
                items.add("No items found in: " + (homeworkPath.isEmpty() ? "root" : homeworkPath));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            items.add("Error: Could not fetch items - " + e.getMessage());
        }
        
        return items;
    }

    /**
     * Fetches the ORIGINAL post timestamp for a file on the main branch.
     * This gets the OLDEST commit (when the file was first introduced), not the newest.
     * @param itemPath Path to the file
     * @return Timestamp of when the file was first committed on main, or 0 if not found
     */
    public long fetchItemTimestamp(String itemPath) {
        long timestamp = 0;
        
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return timestamp;
        }
        
        try {
            // URL-encode the path to handle spaces and special characters
            String encodedPath = java.net.URLEncoder.encode(itemPath, "UTF-8")
                .replace("+", "%20"); // URLEncoder uses + for spaces, but URLs need %20
            
            // Fetch from main branch specifically, get the OLDEST commit (last in the array)
            // Using per_page=100 to get enough history, then take the last one
            String apiUrl = "repos/" + repoName + "/commits?path=" + encodedPath + "&sha=main&per_page=100";
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", apiUrl, "--jq", ".[-1].commit.committer.date"  // .[-1] gets the LAST (oldest) commit
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line = reader.readLine();
                if (line != null && !line.trim().isEmpty()) {
                    String dateStr = line.trim().replaceAll("\"", "");
                    timestamp = java.time.Instant.parse(dateStr).toEpochMilli();
                }
            }
            process.waitFor();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timestamp;
    }

    public int fetchHomeworkItemCount() {
        String repoName = appConfig.getSelectedRepo();
        String homeworkPath = appConfig.getHomeworkFolderPath();
        
        if (repoName == null || repoName.isEmpty()) {
            return -1;
        }
        
        // Handle root path and remove leading slash
        if (homeworkPath == null || homeworkPath.isEmpty() || homeworkPath.equals("/")) {
            homeworkPath = "";
        } else if (homeworkPath.startsWith("/")) {
            homeworkPath = homeworkPath.substring(1);
        }
        
        try {
            String apiUrl = homeworkPath.isEmpty() 
                ? "repos/" + repoName + "/contents"
                : "repos/" + repoName + "/contents/" + homeworkPath;
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", apiUrl, "--jq", "length"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line = reader.readLine();
                if (line != null && !line.trim().isEmpty()) {
                    int count = Integer.parseInt(line.trim());
                    return count - 1; // Subtract 1 for .gitkeep
                }
            }
            process.waitFor();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
}