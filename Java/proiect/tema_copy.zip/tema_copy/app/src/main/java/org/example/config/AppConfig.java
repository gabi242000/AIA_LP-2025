package org.example.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AppConfig {
    private static final String CONFIG_FILE = "app_config.json";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    
    private String selectedRepo;
    private String homeworkFolderPath;
    private Map<String, Long> cachedFileList; // filename -> timestamp
    private boolean filesSorted;
    
    public AppConfig() {
        this.selectedRepo = "";
        this.homeworkFolderPath = "";
        this.cachedFileList = new LinkedHashMap<>(); // Preserves insertion order (sorted order)
        this.filesSorted = false;
    }
    
    public String getSelectedRepo() {
        return selectedRepo;
    }
    
    public void setSelectedRepo(String selectedRepo) {
        this.selectedRepo = selectedRepo;
    }
    
    public String getHomeworkFolderPath() {
        return homeworkFolderPath;
    }
    
    public void setHomeworkFolderPath(String homeworkFolderPath) {
        this.homeworkFolderPath = homeworkFolderPath;
    }
    
    /**
     * Gets the cached file list as a map (filename -> timestamp)
     * @return Map of filenames to timestamps, preserving sorted order
     */
    public Map<String, Long> getCachedFileMap() {
        if (cachedFileList == null) {
            cachedFileList = new LinkedHashMap<>();
        }
        return cachedFileList;
    }
    
    /**
     * Gets just the filenames from cache (in sorted order)
     * @return List of filenames
     */
    public List<String> getCachedFileList() {
        if (cachedFileList == null) {
            cachedFileList = new LinkedHashMap<>();
        }
        return new ArrayList<>(cachedFileList.keySet());
    }
    
    /**
     * Gets the timestamp for a specific file
     * @param filename The filename to look up
     * @return The timestamp, or 0 if not found
     */
    public long getFileTimestamp(String filename) {
        if (cachedFileList == null || !cachedFileList.containsKey(filename)) {
            return 0;
        }
        return cachedFileList.get(filename);
    }
    
    /**
     * Sets the cached file list with timestamps
     * @param fileTimestampMap Map of filename -> timestamp (should be pre-sorted)
     */
    public void setCachedFileList(Map<String, Long> fileTimestampMap) {
        this.cachedFileList = fileTimestampMap != null ? new LinkedHashMap<>(fileTimestampMap) : new LinkedHashMap<>();
        save();
    }
    
    /**
     * Sets the cached file list from a sorted list and timestamp map
     * @param sortedFiles List of filenames in sorted order
     * @param timestampMap Map of filename -> timestamp
     */
    public void setCachedFileList(List<String> sortedFiles, Map<String, Long> timestampMap) {
        this.cachedFileList = new LinkedHashMap<>();
        for (String file : sortedFiles) {
            Long timestamp = timestampMap.get(file);
            this.cachedFileList.put(file, timestamp != null ? timestamp : 0L);
        }
        save();
    }
    
    public boolean hasCachedFileList() {
        return cachedFileList != null && !cachedFileList.isEmpty();
    }
    
    public void clearCachedFileList() {
        this.cachedFileList = new LinkedHashMap<>();
        this.filesSorted = false;
        save();
    }
    
    public Map<String, Long> getCachedTimestamps() {
    // If you're storing timestamps in the config, return them here
    // Otherwise, you'll need to add a field for this
    // For now, return the cached data if available
        if (cachedFileList != null) {
            return new HashMap<>(cachedFileList);
        }
        return new HashMap<>();
    }

    public boolean isFilesSorted() {
        return filesSorted;
    }
    
    public void setFilesSorted(boolean filesSorted) {
        this.filesSorted = filesSorted;
        save();
    }
    
    public boolean isConfigured() {
        return selectedRepo != null && !selectedRepo.isEmpty();
    }
    
    public static AppConfig load() {
        Path configPath = Paths.get(CONFIG_FILE);
        if (Files.exists(configPath)) {
            try (Reader reader = new FileReader(configPath.toFile())) {
                AppConfig config = gson.fromJson(reader, AppConfig.class);
                if (config != null) {
                    if (config.cachedFileList == null) {
                        config.cachedFileList = new LinkedHashMap<>();
                    }
                    return config;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new AppConfig();
    }
    
    public void save() {
        try (Writer writer = new FileWriter(CONFIG_FILE)) {
            gson.toJson(this, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}