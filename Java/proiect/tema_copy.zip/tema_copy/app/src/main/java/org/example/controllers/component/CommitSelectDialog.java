package org.example.controllers.component;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.services.RankingService;
import org.example.services.RankingService.CommitInfo;
import org.example.services.RankingService.CopyResult;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Dialog for selecting a commit from a person and then selecting files to copy.
 * Step 1: Shows list of commits with dates and messages
 * Step 2: Shows checkboxes for file selection
 * Download functionality is TODO.
 */
public class CommitSelectDialog {
    
    private final RankingService rankingService;
    private final String homeworkFile;
    private final String person;
    
    private Stage dialogStage;
    private VBox contentContainer;
    private ListView<CommitEntry> commitListView;
    private VBox fileSelectionContainer;
    private List<CheckBox> fileCheckboxes;
    private Button nextBtn;
    private Button downloadBtn;
    private Button backBtn;
    
    private CommitEntry selectedCommit;
    private List<String> selectedFiles;
    
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMM dd, yyyy HH:mm");
    
    public CommitSelectDialog(RankingService rankingService, String homeworkFile, String person) {
        this.rankingService = rankingService;
        this.homeworkFile = homeworkFile;
        this.person = person;
        this.fileCheckboxes = new ArrayList<>();
        this.selectedFiles = new ArrayList<>();
        
        initializeDialog();
    }
    
    private void initializeDialog() {
        dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.initStyle(StageStyle.DECORATED);
        dialogStage.setTitle("Copy Homework from " + person);
        dialogStage.setMinWidth(500);
        dialogStage.setMinHeight(400);
        
        contentContainer = new VBox(15);
        contentContainer.setPadding(new Insets(20));
        contentContainer.setStyle("-fx-background-color: #1e3d2f;");
        
        // Start with commit selection
        showCommitSelection();
        
        Scene scene = new Scene(contentContainer, 500, 450);
        dialogStage.setScene(scene);
    }
    
    /**
     * Shows Step 1: Commit selection
     */
    private void showCommitSelection() {
        contentContainer.getChildren().clear();
        
        // Title
        Label titleLabel = new Label("Step 1: Select a Commit");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        
        Label subtitleLabel = new Label("Commits from " + person + " for " + homeworkFile);
        subtitleLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #88aa99;");
        
        // Commit list
        List<CommitInfo> commits = rankingService.getCommitsForPerson(homeworkFile, person);
        
        ObservableList<CommitEntry> commitEntries = FXCollections.observableArrayList();
        boolean isFirst = true;
        for (CommitInfo commit : commits) {
            commitEntries.add(new CommitEntry(commit, isFirst));
            isFirst = false;
        }
        
        commitListView = new ListView<>(commitEntries);
        commitListView.setCellFactory(lv -> new CommitListCell());
        commitListView.setStyle("-fx-background-color: #1a2e24; -fx-border-color: #2d5a44;");
        commitListView.setPrefHeight(250);
        VBox.setVgrow(commitListView, Priority.ALWAYS);
        
        // Select first item by default
        if (!commitEntries.isEmpty()) {
            commitListView.getSelectionModel().select(0);
        }
        
        // Buttons
        HBox buttonContainer = new HBox(10);
        buttonContainer.setAlignment(Pos.CENTER_RIGHT);
        
        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("-fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;");
        cancelBtn.setOnAction(e -> dialogStage.close());
        
        nextBtn = new Button("Next →");
        nextBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-cursor: hand;");
        nextBtn.setDisable(commitEntries.isEmpty());
        nextBtn.setOnAction(e -> {
            selectedCommit = commitListView.getSelectionModel().getSelectedItem();
            if (selectedCommit != null) {
                showFileSelection();
            }
        });
        
        buttonContainer.getChildren().addAll(cancelBtn, nextBtn);
        
        // Info label
        Label infoLabel = new Label("★ marks the first commit (used for point calculation)");
        infoLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #668877;");
        
        contentContainer.getChildren().addAll(
            titleLabel,
            subtitleLabel,
            commitListView,
            infoLabel,
            buttonContainer
        );
    }
    
    /**
     * Shows Step 2: File selection with checkboxes
     */
    private void showFileSelection() {
        contentContainer.getChildren().clear();
        fileCheckboxes.clear();
        
        // Title
        Label titleLabel = new Label("Step 2: Select Files to Copy");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        
        Label subtitleLabel = new Label("Commit: " + selectedCommit.commit.oid.substring(0, 7) + 
            " - " + truncateMessage(selectedCommit.commit.message, 50));
        subtitleLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #88aa99;");
        subtitleLabel.setWrapText(true);
        
        // Loading indicator
        ProgressIndicator loadingIndicator = new ProgressIndicator();
        loadingIndicator.setPrefSize(40, 40);
        
        Label loadingLabel = new Label("Loading files...");
        loadingLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #88aa99;");
        
        VBox loadingContainer = new VBox(10, loadingIndicator, loadingLabel);
        loadingContainer.setAlignment(Pos.CENTER);
        loadingContainer.setPadding(new Insets(50));
        
        contentContainer.getChildren().addAll(titleLabel, subtitleLabel, loadingContainer);
        
        // Fetch files asynchronously
        new Thread(() -> {
            List<String> files = rankingService.fetchFilesInCommit(selectedCommit.commit.oid);
            
            javafx.application.Platform.runLater(() -> {
                contentContainer.getChildren().remove(loadingContainer);
                
                if (files.isEmpty()) {
                    Label noFilesLabel = new Label("No files found in this commit.");
                    noFilesLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #ff6b6b;");
                    contentContainer.getChildren().add(noFilesLabel);
                    addFileSelectionButtons(true);
                    return;
                }
                
                // File checkboxes in a scrollable container
                fileSelectionContainer = new VBox(8);
                fileSelectionContainer.setPadding(new Insets(10));
                fileSelectionContainer.setStyle("-fx-background-color: #1a2e24;");
                
                // Select All / Deselect All
                HBox selectAllContainer = new HBox(10);
                selectAllContainer.setAlignment(Pos.CENTER_LEFT);
                
                Button selectAllBtn = new Button("Select All");
                selectAllBtn.setStyle("-fx-font-size: 11px; -fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;");
                selectAllBtn.setOnAction(e -> fileCheckboxes.forEach(cb -> cb.setSelected(true)));
                
                Button deselectAllBtn = new Button("Deselect All");
                deselectAllBtn.setStyle("-fx-font-size: 11px; -fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;");
                deselectAllBtn.setOnAction(e -> fileCheckboxes.forEach(cb -> cb.setSelected(false)));
                
                selectAllContainer.getChildren().addAll(selectAllBtn, deselectAllBtn);
                fileSelectionContainer.getChildren().add(selectAllContainer);
                
                // File checkboxes
                for (String file : files) {
                    CheckBox checkbox = new CheckBox(file);
                    checkbox.setStyle("-fx-font-size: 12px; -fx-text-fill: #ffffff;");
                    checkbox.setSelected(true); // Selected by default
                    fileCheckboxes.add(checkbox);
                    fileSelectionContainer.getChildren().add(checkbox);
                }
                
                ScrollPane scrollPane = new ScrollPane(fileSelectionContainer);
                scrollPane.setStyle("-fx-background: #1a2e24; -fx-background-color: #1a2e24; -fx-border-color: #2d5a44;");
                scrollPane.setFitToWidth(true);
                scrollPane.setPrefHeight(250);
                VBox.setVgrow(scrollPane, Priority.ALWAYS);
                
                // Ensure viewport has proper background
                scrollPane.getContent().setStyle("-fx-background-color: #1a2e24;");
                
                contentContainer.getChildren().add(scrollPane);
                addFileSelectionButtons(false);
            });
        }).start();
    }
    
    private void addFileSelectionButtons(boolean disabled) {
        HBox buttonContainer = new HBox(10);
        buttonContainer.setAlignment(Pos.CENTER_RIGHT);
        
        backBtn = new Button("← Back");
        backBtn.setStyle("-fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;");
        backBtn.setOnAction(e -> showCommitSelection());
        
        Button cancelBtn = new Button("Cancel");
        cancelBtn.setStyle("-fx-background-color: #2d5a44; -fx-text-fill: #88aa99; -fx-cursor: hand;");
        cancelBtn.setOnAction(e -> dialogStage.close());
        
        downloadBtn = new Button("Copy to My Branch");
        downloadBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-cursor: hand;");
        downloadBtn.setDisable(disabled);
        downloadBtn.setOnAction(e -> handleDownload());
        
        buttonContainer.getChildren().addAll(backBtn, cancelBtn, downloadBtn);
        contentContainer.getChildren().add(buttonContainer);
    }
    
    /**
     * Handles the copy action - copies selected files to user's GitHub branch.
     */
    private void handleDownload() {
        // Collect selected files
        selectedFiles.clear();
        for (CheckBox cb : fileCheckboxes) {
            if (cb.isSelected()) {
                selectedFiles.add(cb.getText());
            }
        }
        
        if (selectedFiles.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Files Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select at least one file to copy.");
            styleAlert(alert);
            alert.showAndWait();
            return;
        }
        
        // Step 1: Find user's branch
        String userBranch = rankingService.findUserBranch();
        
        if (userBranch == null) {
            // Could not auto-detect branch
            // Fallback: ask user for their branch name
            TextInputDialog branchDialog = new TextInputDialog();
            branchDialog.setTitle("Branch Not Detected");
            branchDialog.setHeaderText("Could not automatically find your branch");
            branchDialog.setContentText("Please enter your GitHub branch name:");
            styleTextInputDialog(branchDialog);
            
            java.util.Optional<String> result = branchDialog.showAndWait();
            if (result.isPresent() && !result.get().trim().isEmpty()) {
                userBranch = result.get().trim();
            } else {
                return; // User cancelled
            }
        }
        
        // Final check if the branch actually exists (user might have typed it wrong)
        if (!rankingService.checkBranchExists(userBranch)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Branch Not Found");
            alert.setHeaderText("Branch does not exist");
            alert.setContentText(
                "Branch '" + userBranch + "' was not found in the repository.\n\n" +
                "Please make sure the branch exists on GitHub."
            );
            styleAlert(alert);
            alert.showAndWait();
            return;
        }
        
        // Step 3: Show commit message dialog
        String defaultMessage = buildDefaultCommitMessage();
        TextInputDialog commitDialog = new TextInputDialog(defaultMessage);
        
        // ... (rest of the method uses userBranch instead of username)
        
        commitDialog.setTitle("Commit Message");
        commitDialog.setHeaderText("Enter commit message for the copy to branch '" + userBranch + "'");
        commitDialog.setContentText("Message:");
        commitDialog.getEditor().setPrefWidth(400);
        styleTextInputDialog(commitDialog);
        
        java.util.Optional<String> messageResult = commitDialog.showAndWait();
        if (!messageResult.isPresent() || messageResult.get().trim().isEmpty()) {
            return; // User cancelled
        }
        String commitMessage = messageResult.get().trim();
        
        // Step 4: Show progress and perform copy
        downloadBtn.setDisable(true);
        downloadBtn.setText("Copying...");
        
        String finalBranch = userBranch;
        
        new Thread(() -> {
            CopyResult result = rankingService.copyFilesToUserBranch(
                selectedCommit.commit.oid,
                selectedFiles,
                finalBranch,
                commitMessage
            );
            
            javafx.application.Platform.runLater(() -> {
                downloadBtn.setDisable(false);
                downloadBtn.setText("Copy to My Branch");
                
                if (result.success) {
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Success");
                    successAlert.setHeaderText("Files copied successfully!");
                    
                    StringBuilder content = new StringBuilder();
                    content.append("Copied ").append(result.copiedFiles.size())
                           .append(" file(s) to branch '").append(finalBranch).append("'\n\n");
                    
                    // Show renamed files if any
                    if (!result.renamedFiles.isEmpty()) {
                        content.append("Renamed files (to avoid conflicts):\n");
                        for (String renamed : result.renamedFiles) {
                            content.append("  • ").append(renamed).append("\n");
                        }
                        content.append("\n");
                    }
                    
                    content.append("Files copied:\n");
                    int shown = 0;
                    for (String file : result.copiedFiles) {
                        if (shown < 5) {
                            content.append("  • ").append(getFileName(file)).append("\n");
                            shown++;
                        }
                    }
                    if (result.copiedFiles.size() > 5) {
                        content.append("  ... and ").append(result.copiedFiles.size() - 5).append(" more");
                    }
                    
                    successAlert.setContentText(content.toString());
                    styleAlert(successAlert);
                    successAlert.showAndWait();
                    
                    dialogStage.close();
                } else {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setTitle("Copy Failed");
                    errorAlert.setHeaderText("Could not copy files");
                    errorAlert.setContentText(result.message);
                    styleAlert(errorAlert);
                    errorAlert.showAndWait();
                }
            });
        }).start();
    }
    
    /**
     * Builds the default commit message.
     */
    private String buildDefaultCommitMessage() {
        StringBuilder sb = new StringBuilder("Copy from ");
        sb.append(person).append(": ");
        
        if (selectedFiles.size() == 1) {
            sb.append(getFileName(selectedFiles.get(0)));
        } else if (selectedFiles.size() <= 3) {
            for (int i = 0; i < selectedFiles.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(getFileName(selectedFiles.get(i)));
            }
        } else {
            sb.append(selectedFiles.size()).append(" files");
        }
        
        return sb.toString();
    }
    
    /**
     * Extracts filename from a path.
     */
    private String getFileName(String path) {
        int lastSlash = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        return lastSlash >= 0 ? path.substring(lastSlash + 1) : path;
    }
    
    /**
     * Applies dark theme styling to an Alert.
     */
    private void styleAlert(Alert alert) {
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e3d2f;");
        dialogPane.lookup(".content.label").setStyle("-fx-text-fill: #ffffff;");
        if (dialogPane.lookup(".header-panel") != null) {
            dialogPane.lookup(".header-panel").setStyle("-fx-background-color: #1a2e24;");
        }
    }
    
    /**
     * Applies dark theme styling to a TextInputDialog.
     */
    private void styleTextInputDialog(TextInputDialog dialog) {
        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setStyle("-fx-background-color: #1e3d2f;");
        dialog.getEditor().setStyle("-fx-background-color: #1a2e24; -fx-text-fill: #ffffff; -fx-border-color: #2d5a44;");
    }
    
    /**
     * Shows the dialog.
     */
    public void show() {
        dialogStage.showAndWait();
    }
    
    private String truncateMessage(String message, int maxLength) {
        if (message == null) return "";
        String firstLine = message.split("\n")[0];
        if (firstLine.length() > maxLength) {
            return firstLine.substring(0, maxLength - 3) + "...";
        }
        return firstLine;
    }
    
    // ==================== Inner Classes ====================
    
    /**
     * Wrapper for commit info with first-commit flag.
     */
    private static class CommitEntry {
        final CommitInfo commit;
        final boolean isFirst;
        
        CommitEntry(CommitInfo commit, boolean isFirst) {
            this.commit = commit;
            this.isFirst = isFirst;
        }
    }
    
    /**
     * Custom cell for commit list.
     */
    private class CommitListCell extends ListCell<CommitEntry> {
        @Override
        protected void updateItem(CommitEntry entry, boolean empty) {
            super.updateItem(entry, empty);
            
            if (empty || entry == null) {
                setGraphic(null);
                setText(null);
                setStyle("-fx-background-color: #1a2e24;");
                return;
            }
            
            VBox container = new VBox(3);
            container.setPadding(new Insets(8));
            
            // First line: OID + date + first marker
            HBox topLine = new HBox(10);
            topLine.setAlignment(Pos.CENTER_LEFT);
            
            Label oidLabel = new Label(entry.commit.oid.substring(0, 7));
            oidLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #4CAF50; -fx-font-family: monospace;");
            
            Label dateLabel = new Label(DATE_FORMAT.format(new Date(entry.commit.date)));
            dateLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #88aa99;");
            
            topLine.getChildren().addAll(oidLabel, dateLabel);
            
            if (entry.isFirst) {
                Label firstLabel = new Label("★ First commit");
                firstLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #FFD700; -fx-font-weight: bold;");
                topLine.getChildren().add(firstLabel);
            }
            
            // Second line: commit message
            Label messageLabel = new Label(truncateMessage(entry.commit.message, 60));
            messageLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ffffff;");
            messageLabel.setWrapText(true);
            
            // Points if available
            if (entry.commit.points > 0) {
                Label pointsLabel = new Label("+" + entry.commit.points + " pts");
                pointsLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #4CAF50;");
                topLine.getChildren().add(pointsLabel);
            }
            
            container.getChildren().addAll(topLine, messageLabel);
            
            setGraphic(container);
            setText(null);
            
            // Apply selection/hover styling for better visibility
            if (isSelected()) {
                setStyle("-fx-background-color: #2d5a44; -fx-cursor: hand;");
            } else {
                setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
            }
        }
    }
}
