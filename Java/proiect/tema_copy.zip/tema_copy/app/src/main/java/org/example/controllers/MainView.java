package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import org.example.config.AppConfig;
import javafx.scene.layout.Priority;
import javafx.scene.control.ProgressBar;
import javafx.application.Platform;
import org.example.services.RepoFolderSelecter;
import org.example.services.MainLogic;
import org.example.services.RankingService;
import org.example.controllers.component.ExpandableFileListView;
import org.example.controllers.component.DayGroup;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class MainView {
    
    private final SceneController router;
    private BorderPane viewLayout;
    private AppConfig appConfig;
    private RepoFolderSelecter repoFolderSelecter;
    private MainLogic mainLogic;
    private RankingService rankingService;
    private RankingView rankingView;
    
    // Progress bar for ranking refresh (shown in top bar)
    private ProgressBar rankingProgressBar;
    private Label rankingProgressLabel;

    public MainView(SceneController router) {
        this.router = router;
        this.appConfig = AppConfig.load();
        this.repoFolderSelecter = new RepoFolderSelecter(appConfig);
        this.mainLogic = new MainLogic(appConfig);
        this.rankingService = new RankingService(appConfig);
        initializeUI();
    }

    public Pane getView() {
        return viewLayout;
    }

    private void initializeUI() {
        viewLayout = new BorderPane();
        viewLayout.setPadding(new Insets(7));
        
        if (appConfig.isConfigured()) {
            MainApp();
        } else {
            showFirstTimeSetupView();
        }
    }
    
    private void showFirstTimeSetupView() {
        VBox setupContainer = new VBox(20);
        setupContainer.setAlignment(Pos.CENTER);
        
        Label titleLabel = new Label("First Time Setup");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        
        Label repoLabel = new Label("Select Repository:");
        repoLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #88aa99;");
        
        List<String> AVAILABLE_REPOS = RepoFolderSelecter.fetchGitHubRepos();
        ComboBox<String> repoDropdown = new ComboBox<>(FXCollections.observableArrayList(AVAILABLE_REPOS));
        repoDropdown.setPromptText("Choose a repository...");
        repoDropdown.setStyle("-fx-font-size: 14px; -fx-pref-width: 300px;");
        
        Label homeworkLabel = new Label("Homework Folder Detection");
        homeworkLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 20 0 10 0; -fx-text-fill: #4CAF50;");
        
        HBox buttonContainer = new HBox(15);
        buttonContainer.setAlignment(Pos.CENTER);
        
        Button defaultBtn = new Button("Default (Java/Laboratoare)");
        defaultBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 120px;");
        defaultBtn.setDisable(true);
        defaultBtn.setOnAction(e -> {
            appConfig.setHomeworkFolderPath("Java/Laboratoare");
            appConfig.save();
        });
        
        Button manualBtn = new Button("Manual");
        manualBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 120px;");
        manualBtn.setDisable(true);
        manualBtn.setOnAction(e -> {
            String selectedRepo = repoDropdown.getValue();
            if (selectedRepo != null && !selectedRepo.isEmpty()) {
                repoFolderSelecter.showFolderSelectionDialog(selectedRepo);
            }
        });
        
        buttonContainer.getChildren().addAll(defaultBtn, manualBtn);
        
        Button saveBtn = new Button("Save Configuration");
        saveBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 200px;");
        saveBtn.setDisable(true);
        saveBtn.setOnAction(e -> {
            String selectedRepo = repoDropdown.getValue();
            if (selectedRepo != null && !selectedRepo.isEmpty()) {
                appConfig.setSelectedRepo(selectedRepo);
                appConfig.save();
                viewLayout.getChildren().clear();
                MainApp();                
            }
        });
        
        repoDropdown.setOnAction(e -> {
            boolean repoSelected = repoDropdown.getValue() != null;
            defaultBtn.setDisable(!repoSelected);
            manualBtn.setDisable(!repoSelected);
            saveBtn.setDisable(!repoSelected);
        });
        
        setupContainer.getChildren().addAll(
            titleLabel,
            repoLabel,
            repoDropdown,
            homeworkLabel,
            buttonContainer,
            saveBtn
        );
        
        viewLayout.setCenter(setupContainer);
    }
    
    // ...existing code...

    private void loadFilesWithTimestamps(VBox contentContainer, ExpandableFileListView filesList) {
        // Fetch files from API
        List<String> files = mainLogic.fetchHomeworkItems();
        
        // Progress bar setup
        VBox progressContainer = new VBox(5);
        progressContainer.setAlignment(Pos.CENTER);
        ProgressBar progressBar = new ProgressBar(0);
        progressBar.setPrefWidth(280);
        progressBar.setPrefHeight(20);
        Label progressLabel = new Label("Loading timestamps...");
        progressLabel.setStyle("-fx-font-size: 12px;");
        progressContainer.getChildren().addAll(progressLabel, progressBar);
        
        // Remove any existing refresh label
        contentContainer.getChildren().removeIf(node -> 
            node instanceof Label && ((Label) node).getText().contains("Refreshing"));
        
        contentContainer.getChildren().clear();
        contentContainer.getChildren().addAll(progressContainer, filesList);
        
        new Thread(() -> {
            long startTime = System.currentTimeMillis();
            System.out.println("\n=== STARTING SORTING ===");
            System.out.println("Fetching timestamps for " + files.size() + " files...");
            
            List<String> timedFiles = new ArrayList<>(files);
            Map<String, Long> timestampMap = new HashMap<>();
            String homeworkPath = appConfig.getHomeworkFolderPath();
            System.out.println("Using homework path: " + (homeworkPath.isEmpty() ? "(root)" : homeworkPath));
            
            int totalFiles = timedFiles.size();
            int[] processedCount = {0};
            
            for (String file : timedFiles) {
                String fullPath = homeworkPath.isEmpty() ? file : homeworkPath + "/" + file;
                System.out.println("Fetching timestamp for: " + fullPath);
                long timestamp = mainLogic.fetchItemTimestamp(fullPath);
                timestampMap.put(file, timestamp);
                System.out.println("Fetched timestamp for " + file + ": " + timestamp);
                
                processedCount[0]++;
                double progress = (double) processedCount[0] / totalFiles;
                
                Platform.runLater(() -> {
                    progressBar.setProgress(progress);
                    progressLabel.setText("Loading timestamps... " + processedCount[0] + "/" + totalFiles);
                });
            }
            
            long endTime = System.currentTimeMillis();
            
            System.out.println("\n=== SORTING RESULTS ===");
            System.out.println("Total time: " + (endTime - startTime) + "ms");
            System.out.println("Sorted files (newest first):");
            for (String file : timedFiles) {
                System.out.println("  " + file + " -> " + timestampMap.get(file));
            }
            System.out.println("========================\n");
            
            Platform.runLater(() -> {
                contentContainer.getChildren().remove(progressContainer);
                filesList.setPrefHeight(400);
                filesList.setFilesWithTimestamps(timedFiles, timestampMap);                
                
                // Save to cache with timestamps and mark as sorted
                appConfig.setCachedFileList(timedFiles, timestampMap);
                appConfig.setFilesSorted(true);
                
                // Set total homework count for the ranking view
                rankingView.setTotalHomeworkCount(countHomeworkFiles(timedFiles));
                
                // Trigger ranking refresh after files are loaded (for first startup)
                triggerAsyncRankingRefresh();
            });
        }).start();
    }
    
    /**
     * Counts the number of homework files in a list.
     */
    private int countHomeworkFiles(List<String> files) {
        if (files == null) return 0;
        int count = 0;
        for (String file : files) {
            if (RankingService.isHomeworkFile(file)) {
                count++;
            }
        }
        return count;
    }

    ///ocupate de custom list view care minimizeaza datele de UI , apoi treci la clasament in sfarsit

    private void MainApp() {
        // Create the ranking view
        rankingView = new RankingView(appConfig, rankingService);
        
        // Left side: File list
        VBox contentContainer = new VBox(15);
        contentContainer.setAlignment(Pos.CENTER);
        
        ExpandableFileListView filesList = new ExpandableFileListView();
        filesList.setStyle("-fx-font-size: 14px;");
        filesList.setPrefHeight(620);
        filesList.setMaxWidth(450);
        contentContainer.setAlignment(Pos.CENTER_LEFT);
        contentContainer.setPadding(new Insets(10));
        
        // Add click listener to notify ranking view of selected homework
        filesList.setOnMouseClicked(event -> {
            DayGroup selectedGroup = filesList.getSelectionModel().getSelectedItem();
            if (selectedGroup != null && !selectedGroup.getFiles().isEmpty()) {
                // Use the first file in the group as the homework identifier
                String selectedFile = selectedGroup.getFiles().get(0);
                rankingView.setCurrentHomework(selectedFile);
                
                // Calculate homework index if it's a homework file
                if (RankingService.isHomeworkFile(selectedFile)) {
                    List<String> allFiles = appConfig.getCachedFileList();
                    if (allFiles != null) {
                        // Count homework files and find index (from newest to oldest, so reverse)
                        int homeworkIndex = 0;
                        int totalHomework = 0;
                        for (String file : allFiles) {
                            if (RankingService.isHomeworkFile(file)) {
                                totalHomework++;
                                if (file.equals(selectedFile)) {
                                    homeworkIndex = totalHomework;
                                }
                            }
                        }
                        // Display as (index/total) - index is from top (newest first)
                        rankingView.setHomeworkCount(homeworkIndex, totalHomework);
                    }
                } else {
                    // Not a homework file, show only total
                    rankingView.setHomeworkCount(-1, countHomeworkFiles(appConfig.getCachedFileList()));
                }
            }
        });
        
        // Check if we have cached and sorted files
        if (appConfig.hasCachedFileList() && appConfig.isFilesSorted()) {
            // Use cached files - fast path
            System.out.println("=== USING CACHED FILE LIST ===");
            List<String> cachedFiles = appConfig.getCachedFileList();
            Map<String, Long> cachedTimestamps = appConfig.getCachedTimestamps();
            filesList.setFilesWithTimestamps(cachedFiles, cachedTimestamps);
            contentContainer.getChildren().add(filesList);
            
            // Set total homework count for the ranking view
            rankingView.setTotalHomeworkCount(countHomeworkFiles(cachedFiles));
            
            // Check in background if file count changed
            new Thread(() -> {
                int remoteCount = mainLogic.fetchHomeworkItemCount();
                int cachedCount = cachedFiles.size();
                
                System.out.println("Remote file count: " + remoteCount + ", Cached count: " + cachedCount);
                
                if (remoteCount != -1 && remoteCount != cachedCount) {
                    System.out.println("File count mismatch! Refreshing cache...");
                    Platform.runLater(() -> {
                        // Clear cache and reload
                        appConfig.clearCachedFileList();
                        // Show a notification or refresh the view
                        Label refreshLabel = new Label("New files detected! Refreshing...");
                        refreshLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #4CAF50;");
                        contentContainer.getChildren().add(0, refreshLabel);
                        
                        // Reload with fresh data
                        loadFilesWithTimestamps(contentContainer, filesList);
                    });
                } else {
                    System.out.println("Cache is up to date.");
                }
            }).start();
            
        } else {
            // No cache or not sorted - need to fetch and sort
            System.out.println("=== NO CACHE - FETCHING FILES ===");
            loadFilesWithTimestamps(contentContainer, filesList);
        }
        
        // Create SplitPane with file list on left, ranking on right
        SplitPane splitPane = new SplitPane();
        splitPane.setOrientation(Orientation.HORIZONTAL);
        splitPane.getItems().addAll(contentContainer, rankingView);
        splitPane.setDividerPositions(0.55);
        
        viewLayout.setCenter(splitPane);
        
        // Create a container for the top region with padding to push down from edge
        HBox topContainer = new HBox(10);
        topContainer.setAlignment(Pos.CENTER_LEFT);
        topContainer.setPadding(new Insets(5, 10, 8, 10));
        
        Label repo_folderLabel = new Label();
        repo_folderLabel.setText("Repo: " + appConfig.getSelectedRepo() + " | Homework Folder: " + 
            (appConfig.getHomeworkFolderPath().isEmpty() ? "(Not set)" : appConfig.getHomeworkFolderPath()));        
        repo_folderLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #88aa99;");
        
        // Progress indicator inline in top bar (hidden by default)
        rankingProgressBar = new ProgressBar(0);
        rankingProgressBar.setPrefWidth(150);
        rankingProgressBar.setPrefHeight(12);
        rankingProgressBar.setStyle("-fx-accent: #4CAF50;");
        rankingProgressBar.setVisible(false);
        
        rankingProgressLabel = new Label("Refreshing...");
        rankingProgressLabel.setStyle("-fx-font-size: 10px; -fx-text-fill: #4CAF50;");
        rankingProgressLabel.setVisible(false);
        
        // Spacer to push settings button to the right
        Pane spacer = new Pane();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Button settingsBtn = new Button("\u2699");
        settingsBtn.setStyle("-fx-font-size: 16px; -fx-cursor: hand; -fx-background-color: #1e3d2f; -fx-text-fill: #4CAF50; -fx-border-color: #2d5a44; -fx-border-radius: 4; -fx-background-radius: 4;");
        settingsBtn.setOnAction(e -> router.activate("SETTINGS"));
        
        topContainer.getChildren().addAll(repo_folderLabel, rankingProgressLabel, rankingProgressBar, spacer, settingsBtn);
        viewLayout.setTop(topContainer);
        
        // Trigger async ranking refresh (doesn't block UI)
        triggerAsyncRankingRefresh();
    }
    
    /**
     * Triggers async ranking refresh on startup.
     * Shows progress in the top bar inline.
     */
    private void triggerAsyncRankingRefresh() {
        // Only refresh if we have cached files (homework data available)
        if (!appConfig.hasCachedFileList()) {
            return;
        }
        
        // Show inline progress in top bar
        rankingProgressBar.setVisible(true);
        rankingProgressLabel.setVisible(true);
        rankingProgressBar.setProgress(0);
        rankingProgressLabel.setText("Refreshing...");
        
        rankingView.triggerRefreshWithExternalProgress(
            rankingProgressBar,
            () -> {
                // Hide progress when complete
                rankingProgressBar.setVisible(false);
                rankingProgressLabel.setVisible(false);
            }
        );
    }
}