package org.example.services;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import org.example.config.AppConfig;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class RepoFolderSelecter {
    
    private final AppConfig appConfig;
    
    public RepoFolderSelecter(AppConfig appConfig) {
        this.appConfig = appConfig;
    }
    
    public static List<String> fetchGitHubRepos() {
        List<String> repos = new ArrayList<>();
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "/user/repos", "--paginate", "-q", ".[].full_name"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    line = line.trim();
                    if (!line.isEmpty()) {
                        repos.add(line);
                    }
                }
            }
            
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
            repos.add("Error: Could not fetch repositories");
        }
        
        return repos;
    }
    
    public void showFolderSelectionDialog(String repoName) {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Select Homework Folder");
        dialog.setHeaderText("Choose the homework folder path for: " + repoName);
        dialog.initModality(Modality.APPLICATION_MODAL);
        
        VBox dialogContent = new VBox(10);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setAlignment(Pos.CENTER_LEFT);
        
        HBox pathContainer = new HBox(5);
        pathContainer.setAlignment(Pos.CENTER_LEFT);
        
        Button rootBtn = new Button("/ (Root)");
        rootBtn.setStyle("-fx-font-size: 12px; -fx-cursor: hand;");
        rootBtn.setOnAction(e -> {
            pathContainer.getChildren().clear();
            pathContainer.getChildren().add(rootBtn);
            addFolderDropdown(pathContainer, "", repoName);
        });
        pathContainer.getChildren().add(rootBtn);
        
        addFolderDropdown(pathContainer, "", repoName);
        
        ScrollPane scrollPane = new ScrollPane(pathContainer);
        scrollPane.setFitToHeight(true);
        scrollPane.setStyle("-fx-background-color: transparent;");
        
        Label instructionLabel = new Label("Click on a folder to go back to that level");
        instructionLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: gray;");
        
        dialogContent.getChildren().addAll(instructionLabel, scrollPane);
        
        dialog.getDialogPane().setContent(dialogContent);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        dialog.setResultConverter(buttonType -> {
            if (buttonType == ButtonType.OK) {
                StringBuilder path = new StringBuilder();
                for (var node : pathContainer.getChildren()) {
                    if (node instanceof Label) {
                        Label label = (Label) node;
                        path.append(label.getText());
                    }
                }
                return path.toString().isEmpty() ? "/" : path.toString();
            }
            return null;
        });
        
        dialog.showAndWait().ifPresent(selectedPath -> {
            appConfig.setHomeworkFolderPath(selectedPath);
            appConfig.save();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText(null);
            alert.setContentText("Homework folder path set to: " + selectedPath);
            alert.showAndWait();
        });
    }
    
    public static void addFolderDropdown(HBox pathContainer, String currentPath, String repoName) {
        List<String> folders = fetchFoldersFromRepo(repoName, currentPath);
        
        if (folders.isEmpty()) {
            return;
        }
        
        ComboBox<String> folderDropdown = new ComboBox<>(FXCollections.observableArrayList(folders));
        folderDropdown.setPromptText("Choose folder...");
        folderDropdown.setStyle("-fx-font-size: 12px;");
        
        folderDropdown.setOnAction(e -> {
            String selectedFolder = folderDropdown.getValue();
            if (selectedFolder != null && !selectedFolder.equals("(Here)")) {
                int index = pathContainer.getChildren().indexOf(folderDropdown);
                pathContainer.getChildren().remove(index, pathContainer.getChildren().size());
                
                String newPath = currentPath.isEmpty() ? selectedFolder : currentPath + "/" + selectedFolder;
                
                // Create clickable label
                Label folderLabel = createClickableLabel(selectedFolder, currentPath, repoName, pathContainer);
                pathContainer.getChildren().add(folderLabel);
                
                addFolderDropdown(pathContainer, newPath, repoName);
            } else if (selectedFolder != null && selectedFolder.equals("(Here)")) {
                int index = pathContainer.getChildren().indexOf(folderDropdown);
                pathContainer.getChildren().remove(index, pathContainer.getChildren().size());
            }
        });
        
        pathContainer.getChildren().add(folderDropdown);
        javafx.application.Platform.runLater(() -> folderDropdown.show());
    }
    
    private static Label createClickableLabel(String folderName, String parentPath, String repoName, HBox pathContainer) {
        Label folderLabel = new Label("/" + folderName);
        folderLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-cursor: hand; -fx-underline: false;");
        
        // Hover effect
        folderLabel.setOnMouseEntered(e -> {
            folderLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-cursor: hand; -fx-text-fill: #4a90d9; -fx-underline: true;");
        });
        folderLabel.setOnMouseExited(e -> {
            folderLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-cursor: hand; -fx-underline: false;");
        });
        
        // Click to go back to this level
        folderLabel.setOnMouseClicked(e -> {
            int labelIndex = pathContainer.getChildren().indexOf(folderLabel);
            
            // Remove everything after this label (including the label itself)
            pathContainer.getChildren().remove(labelIndex, pathContainer.getChildren().size());
            
            // Add dropdown at this level (parentPath is the path BEFORE this folder)
            addFolderDropdown(pathContainer, parentPath, repoName);
        });
        
        return folderLabel;
    }
    
    public static List<String> fetchFoldersFromRepo(String repoName, String path) {
        List<String> folders = new ArrayList<>();
        folders.add("(Here)");
        
        try {            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/trees/main?recursive=1"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            StringBuilder jsonOutput = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonOutput.append(line);
                }
            }
            process.waitFor();
            String json = jsonOutput.toString();

            int index = 0;
            while ((index = json.indexOf("\"path\":", index)) != -1) {
                int pathStart = json.indexOf("\"", index + 7) + 1;
                int pathEnd = json.indexOf("\"", pathStart);
                String folderPath = json.substring(pathStart, pathEnd);
                
                int blockEnd = json.indexOf("}", index);
                String block = json.substring(index, Math.min(blockEnd + 1, json.length()));
                
                if (block.contains("\"type\":\"tree\"")) {                    
                    if (path.isEmpty()) {
                        if (!folderPath.contains("/")) {
                            folders.add(folderPath);
                        }
                    } else {
                        if (folderPath.startsWith(path + "/")) {
                            String remaining = folderPath.substring(path.length() + 1);
                            if (!remaining.contains("/")) {
                                folders.add(remaining);
                            }
                        }
                    }
                }                
                index = pathEnd;
            }            
        } catch (Exception e) {
            System.out.println("DEBUG: Exception occurred:");
            e.printStackTrace();
        }
        
        return folders;
    }
}