package org.example;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.example.controllers.LoginView;
import org.example.controllers.MainView;
import org.example.controllers.SettingsView;
import org.example.controllers.SceneController;
import org.example.controllers.TokenWarningDialog;
import org.example.services.Login;
import org.example.services.RankingService;
import org.example.config.AppConfig;

public class App extends Application {

    private RankingService rankingService;
    private SceneController router;

    @Override
    public void start(Stage primaryStage) {
        //custom title bar
        primaryStage.initStyle(StageStyle.UNDECORATED);
        // 1. Create the Router
        router = new SceneController(primaryStage);

        // 2. Create Views, passing the router so they can switch scenes
        // Note: We need to modify LoginView and MainView to return a Pane (getView())
        LoginView loginView = new LoginView(router);
        MainView mainView = new MainView(router);
        SettingsView settingsView = new SettingsView(router);

        // 3. Register Views
        router.addScreen("LOGIN", loginView.getView());
        router.addScreen("MAIN", mainView.getView());
        router.addScreen("SETTINGS", settingsView.getView()); 

        // 4. Start at Login or Main based on auth status
        if(Login.checkGitHubAuthStatus() == 1) {
            router.activate("MAIN");
            
            // 5. Check token validity asynchronously (doesn't block app startup)
            checkTokenValidityAsync();
        } else {
            router.activate("LOGIN");
        }
        
        primaryStage.setTitle("My Application");
        primaryStage.show();
    }
    
    /**
     * Checks GitHub token validity in background thread.
     * Shows warning dialog if token is invalid/expired without blocking startup.
     */
    private void checkTokenValidityAsync() {
        AppConfig appConfig = AppConfig.load();
        rankingService = new RankingService(appConfig);
        
        rankingService.checkTokenValidityAsync().thenAccept(tokenStatus -> {
            if (!tokenStatus.isValid) {
                // Token invalid - show warning on JavaFX thread
                Platform.runLater(() -> {
                    boolean continueAnyway = TokenWarningDialog.showWarning(
                        router,
                        tokenStatus.errorMessage,
                        () -> {
                            // User chose to logout - go to login screen
                            Login.logout();
                            router.activate("LOGIN");
                        }
                    );
                    
                    if (continueAnyway) {
                        System.out.println("User chose to continue with invalid token");
                    }
                });
            } else {
                System.out.println("Token is valid, hasRepoScope: " + tokenStatus.hasRepoScope);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}