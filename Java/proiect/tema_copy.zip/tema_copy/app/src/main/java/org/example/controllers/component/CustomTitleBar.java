package org.example.controllers.component;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

public class CustomTitleBar extends HBox {

    private double xOffset = 0;
    private double yOffset = 0;

    public CustomTitleBar(Stage stage, String title) {
        // Styling
        this.setStyle("-fx-background-color: #1a1a1a; -fx-padding: 5 10;");
        this.setAlignment(Pos.CENTER_LEFT);
        this.setPrefHeight(30);

        // Title
        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");

        // Spacer to push buttons to the right
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Window control buttons
        Button minimizeBtn = new Button("—");
        ///Button maximizeBtn = new Button("☐");
        Button closeBtn = new Button("✕");

        String btnStyle = "-fx-background-color: transparent; -fx-text-fill: white; -fx-font-size: 12px; -fx-cursor: hand;";
        minimizeBtn.setStyle(btnStyle);
        ///maximizeBtn.setStyle(btnStyle);
        /// ia ca nu mai dati nicium maximize ce sa stau eu sa va fac si resizeul acm in ajunu craciunului 
        /// e na
        closeBtn.setStyle(btnStyle + "-fx-text-fill: #ff5555;");

        // Button actions
        minimizeBtn.setOnAction(e -> stage.setIconified(true));
        ///maximizeBtn.setOnAction(e -> stage.setMaximized(!stage.isMaximized()));
        closeBtn.setOnAction(e -> stage.close());

        // Enable dragging the window
        this.setOnMousePressed(event -> {
            xOffset = event.getSceneX();
            yOffset = event.getSceneY();
        });
        this.setOnMouseDragged(event -> {
            stage.setX(event.getScreenX() - xOffset);
            stage.setY(event.getScreenY() - yOffset);
        });

        this.getChildren().addAll(titleLabel, spacer, minimizeBtn, closeBtn);
    }
}