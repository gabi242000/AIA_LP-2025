package org.example.controllers;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;

import java.util.Optional;

/**
 * Dialog shown when GitHub token is invalid or expired.
 * Explains which features will not work and offers options to logout or continue.
 */
public class TokenWarningDialog {
    
    private final SceneController router;
    private final String errorMessage;
    private final Runnable onLogout;
    
    /**
     * Creates a token warning dialog.
     * @param router The scene controller for navigation
     * @param errorMessage The specific error message from token validation
     * @param onLogout Callback to execute when user chooses to logout
     */
    public TokenWarningDialog(SceneController router, String errorMessage, Runnable onLogout) {
        this.router = router;
        this.errorMessage = errorMessage;
        this.onLogout = onLogout;
    }
    
    /**
     * Shows the warning dialog and returns user's choice.
     * @return true if user chose to continue, false if user chose to logout
     */
    public boolean show() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.setTitle("GitHub Token Issue");
        alert.setHeaderText("Authentication Problem Detected");
        
        // Build detailed content
        VBox content = new VBox(15);
        content.setPadding(new Insets(10));
        
        // Error message
        Label errorLabel = new Label(errorMessage != null ? errorMessage : "Your GitHub token is invalid or expired.");
        errorLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #ff6b6b; -fx-font-weight: bold;");
        errorLabel.setWrapText(true);
        
        // Affected features
        Label affectedLabel = new Label("The following features will NOT work:");
        affectedLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold;");
        
        VBox featuresList = new VBox(5);
        featuresList.setPadding(new Insets(0, 0, 0, 20));
        
        String[] affectedFeatures = {
            "• Ranking/Leaderboard calculation",
            "• Viewing commits from other users",
            "• Copying homework from others",
            "• Refreshing file lists from repository"
        };
        
        for (String feature : affectedFeatures) {
            Label featureLabel = new Label(feature);
            featureLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #ffaa00;");
            featuresList.getChildren().add(featureLabel);
        }
        
        // Working features
        Label workingLabel = new Label("Features that WILL still work:");
        workingLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-padding: 10 0 0 0;");
        
        VBox workingList = new VBox(5);
        workingList.setPadding(new Insets(0, 0, 0, 20));
        
        String[] workingFeatures = {
            "• Viewing cached file list",
            "• Viewing cached rankings (if available)",
            "• Application settings"
        };
        
        for (String feature : workingFeatures) {
            Label featureLabel = new Label(feature);
            featureLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #4CAF50;");
            workingList.getChildren().add(featureLabel);
        }
        
        // Recommendation
        Label recommendLabel = new Label("Recommendation: Re-authenticate to restore full functionality.");
        recommendLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #88aa99; -fx-padding: 15 0 0 0;");
        recommendLabel.setWrapText(true);
        
        content.getChildren().addAll(
            errorLabel,
            affectedLabel,
            featuresList,
            workingLabel,
            workingList,
            recommendLabel
        );
        
        alert.getDialogPane().setContent(content);
        alert.getDialogPane().setMinWidth(450);
        alert.getDialogPane().setMinHeight(350);
        
        // Custom buttons
        ButtonType logoutButton = new ButtonType("Logout & Re-authenticate");
        ButtonType continueButton = new ButtonType("Continue Anyway");
        
        alert.getButtonTypes().setAll(logoutButton, continueButton);
        
        // Style the dialog
        alert.getDialogPane().setStyle(
            "-fx-background-color: #1e3d2f; " +
            "-fx-border-color: #2d5a44; " +
            "-fx-border-width: 2;"
        );
        
        Optional<ButtonType> result = alert.showAndWait();
        
        if (result.isPresent() && result.get() == logoutButton) {
            // User chose to logout
            if (onLogout != null) {
                onLogout.run();
            }
            return false;
        }
        
        // User chose to continue
        return true;
    }
    
    /**
     * Static method to create and show the dialog.
     * @param router The scene controller
     * @param errorMessage The error message
     * @param onLogout Callback for logout action
     * @return true if user continues, false if user logs out
     */
    public static boolean showWarning(SceneController router, String errorMessage, Runnable onLogout) {
        TokenWarningDialog dialog = new TokenWarningDialog(router, errorMessage, onLogout);
        return dialog.show();
    }
}
