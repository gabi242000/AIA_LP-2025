package org.example.controllers;

import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

import java.util.List;

import org.example.config.AppConfig;
import org.example.services.RepoFolderSelecter;

public class SettingsView {
    private final SceneController router;
    private BorderPane viewLayout;
    private AppConfig appConfig;
    private RepoFolderSelecter repoFolderSelecter;

    public SettingsView(SceneController router) {
        this.router = router;
        this.appConfig = AppConfig.load();
        this.repoFolderSelecter = new RepoFolderSelecter(appConfig);
        initializeUI();
    }

    public Pane getView() {
        return viewLayout;
    }

    private void initializeUI() {
        viewLayout = new BorderPane();
        
        Button backBtn = new Button("⬅");
        backBtn.setTooltip(new javafx.scene.control.Tooltip("Back to Main"));
        backBtn.setStyle("-fx-font-size: 16px; -fx-cursor: hand; -fx-background-color: #1e3d2f; -fx-text-fill: #4CAF50; -fx-border-color: #2d5a44; -fx-border-radius: 4; -fx-background-radius: 4;");
        backBtn.setOnAction(e -> {
            router.activate("MAIN");
        });

        VBox setupContainer = new VBox(10);
        setupContainer.setAlignment(Pos.CENTER);
        
        Label titleLabel = new Label("Change homework repository");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");
        
        Label repoLabel = new Label("Select Repository:");
        repoLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #88aa99;");
        
        List<String> AVAILABLE_REPOS = RepoFolderSelecter.fetchGitHubRepos();
        ComboBox<String> repoDropdown = new ComboBox<>(FXCollections.observableArrayList(AVAILABLE_REPOS));
        repoDropdown.setPromptText("Choose a repository...");
        repoDropdown.setStyle("-fx-font-size: 14px; -fx-pref-width: 300px;");
        
        // Pre-select current repo if configured
        if (appConfig.getSelectedRepo() != null && !appConfig.getSelectedRepo().isEmpty()) {
            repoDropdown.setValue(appConfig.getSelectedRepo());
        }
        
        Label homeworkLabel = new Label("Homework Folder Detection");
        homeworkLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 20 0 10 0; -fx-text-fill: #4CAF50;");
        
        HBox buttonContainer = new HBox(15);
        buttonContainer.setAlignment(Pos.CENTER);
        
        Button defaultBtn = new Button("Default (Java/Laboratoare)");
        defaultBtn.setTooltip(new javafx.scene.control.Tooltip("Sets homework folder path to Java/Laboratoare"));
        defaultBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 200px;");
        defaultBtn.setOnAction(e -> {
            appConfig.setHomeworkFolderPath("Java/Laboratoare");
            appConfig.save();
            showSuccessAlert("Homework folder path set to: Java/Laboratoare");
        });
        
        Button manualBtn = new Button("Manual");
        manualBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 120px;");
        manualBtn.setOnAction(e -> {
            String selectedRepo = repoDropdown.getValue();
            if (selectedRepo != null && !selectedRepo.isEmpty()) {
                repoFolderSelecter.showFolderSelectionDialog(selectedRepo);
            }
        });
        
        buttonContainer.getChildren().addAll(defaultBtn, manualBtn);
        
        Button saveBtn = new Button("Save Configuration");
        saveBtn.setStyle("-fx-font-size: 14px; -fx-cursor: hand; -fx-pref-width: 200px;");
        saveBtn.setOnAction(e -> {
            String selectedRepo = repoDropdown.getValue();
            if (selectedRepo != null && !selectedRepo.isEmpty()) {
                appConfig.setSelectedRepo(selectedRepo);
                appConfig.save();
                showSuccessAlert("Configuration saved!");
                router.activate("MAIN");
            }
        });
        
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-font-size: 16px; -fx-cursor: hand; -fx-background-color: #5a2d2d; -fx-text-fill: #ff8888; -fx-border-color: #7a3d3d; -fx-border-radius: 4; -fx-background-radius: 4;");
        logoutBtn.setOnAction(e -> {
            router.activate("LOGIN");
        });
        
        setupContainer.getChildren().addAll(
            titleLabel,
            repoLabel,
            repoDropdown,
            homeworkLabel,
            buttonContainer,
            saveBtn
        );

        viewLayout.setCenter(setupContainer);
        viewLayout.setTop(backBtn);
        viewLayout.setBottom(logoutBtn);
        BorderPane.setAlignment(backBtn, Pos.CENTER_LEFT);
        BorderPane.setAlignment(logoutBtn, Pos.CENTER);
        BorderPane.setMargin(logoutBtn, new javafx.geometry.Insets(10, 0 , 10 , 0));
    }
    
    private void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}