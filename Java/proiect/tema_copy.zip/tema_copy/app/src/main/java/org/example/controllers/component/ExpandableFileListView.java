package org.example.controllers.component;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView;

import java.text.SimpleDateFormat;
import java.util.*;

public class ExpandableFileListView extends ListView<DayGroup> {
    
    private final ObservableList<DayGroup> dayGroups;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMM dd, yyyy");

    public ExpandableFileListView() {
        dayGroups = FXCollections.observableArrayList();
        setItems(dayGroups);
        setCellFactory(listView -> new ExpandableListCell(this));
        setStyle("-fx-font-size: 14px;");
    }

    /**
     * Groups files by day based on their timestamps
     * @param files List of file names
     * @param timestampMap Map of file names to timestamps (milliseconds)
     */
    public void setFilesWithTimestamps(List<String> files, Map<String, Long> timestampMap) {
        dayGroups.clear();
        
        // Group files by day
        Map<String, DayGroup> groupMap = new LinkedHashMap<>();
        
        // Sort files by timestamp first (newest first)
        List<String> sortedFiles = new ArrayList<>(files);
        sortedFiles.sort((a, b) -> {
            Long tsA = timestampMap.getOrDefault(a, 0L);
            Long tsB = timestampMap.getOrDefault(b, 0L);
            return Long.compare(tsB, tsA); // Newest first
        });
        
        for (String file : sortedFiles) {
            Long timestamp = timestampMap.getOrDefault(file, 0L);
            String dateKey = formatDate(timestamp);
            
            DayGroup group = groupMap.computeIfAbsent(dateKey, DayGroup::new);
            group.addFile(file);
        }
        
        dayGroups.addAll(groupMap.values());
    }

    /**
     * Sets files from cache (already sorted, with stored timestamps)
     */
    public void setFilesFromCache(List<String> files, Map<String, Long> timestampMap) {
        setFilesWithTimestamps(files, timestampMap);
    }

    /**
     * Gets all files in a flat list (expanded view)
     */
    public List<String> getAllFiles() {
        List<String> allFiles = new ArrayList<>();
        for (DayGroup group : dayGroups) {
            allFiles.addAll(group.getFiles());
        }
        return allFiles;
    }

    /**
     * Collapse all expanded groups
     */
    public void collapseAll() {
        for (DayGroup group : dayGroups) {
            group.setExpanded(false);
        }
        refresh();
    }

    /**
     * Expand all groups
     */
    public void expandAll() {
        for (DayGroup group : dayGroups) {
            if (group.hasMultipleFiles()) {
                group.setExpanded(true);
            }
        }
        refresh();
    }

    private String formatDate(Long timestamp) {
        if (timestamp == null || timestamp == 0) {
            return "Unknown Date";
        }
        return DATE_FORMAT.format(new Date(timestamp));
    }
}