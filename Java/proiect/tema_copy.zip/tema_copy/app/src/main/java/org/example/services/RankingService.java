package org.example.services;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.example.config.AppConfig;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/**
 * Service for managing homework rankings based on commit timing.
 * Uses GitHub GraphQL API to fetch commits per branch within 5-day periods.
 * Points are calculated based on first commit only: 5 pts for day 1, down to 1 pt for day 5.
 */
public class RankingService {
    
    private static final String RANKING_FILE = "ranking_data.json";
    private static final String DEBUG_FILE = "ranking_debug.txt";
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_RETRIES = 3;
    private static final int[] RETRY_DELAYS = {1000, 2000, 4000}; // Exponential backoff in ms
    private static final int PERIOD_DAYS = 5;
    
    // Homework file pattern: matches tema, teme, tem, t1-t9, homework, hw variations
    private static final java.util.regex.Pattern HOMEWORK_PATTERN = java.util.regex.Pattern.compile(
        "(?i).*(tema|teme|tem|t[1-9]|homework|hw).*",
        java.util.regex.Pattern.CASE_INSENSITIVE
    );
    
    private final AppConfig appConfig;
    private RankingData rankingData;
    
    public RankingService(AppConfig appConfig) {
        this.appConfig = appConfig;
        this.rankingData = loadRankingData();
    }
    
    // ==================== Token Validation ====================
    
    /**
     * Checks if the GitHub token is valid and has required permissions.
     * @return CompletableFuture with TokenStatus containing validity and scope info
     */
    public CompletableFuture<TokenStatus> checkTokenValidityAsync() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                ProcessBuilder processBuilder = new ProcessBuilder(
                    "gh", "auth", "status"
                );
                processBuilder.redirectErrorStream(true);
                Process process = processBuilder.start();
                
                StringBuilder output = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line).append("\n");
                    }
                }
                
                int exitCode = process.waitFor();
                String outputStr = output.toString();
                
                if (exitCode == 0) {
                    // Token is valid - check for repo scope
                    boolean hasRepoScope = outputStr.contains("repo") || 
                                          outputStr.contains("Token scopes:");
                    return new TokenStatus(true, hasRepoScope, null);
                } else {
                    // Token invalid or expired
                    String errorMsg = "GitHub token is invalid or expired.";
                    if (outputStr.contains("expired")) {
                        errorMsg = "GitHub token has expired.";
                    } else if (outputStr.contains("not logged")) {
                        errorMsg = "Not logged in to GitHub CLI.";
                    }
                    return new TokenStatus(false, false, errorMsg);
                }
                
            } catch (IOException e) {
                return new TokenStatus(false, false, "GitHub CLI not installed or not in PATH.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return new TokenStatus(false, false, "Token check interrupted.");
            }
        });
    }
    
    /**
     * Synchronous token validity check.
     */
    public TokenStatus checkTokenValidity() {
        return checkTokenValidityAsync().join();
    }
    
    // ==================== Ranking Data Management ====================
    
    /**
     * Loads ranking data from file.
     */
    private RankingData loadRankingData() {
        Path rankingPath = Paths.get(RANKING_FILE);
        if (Files.exists(rankingPath)) {
            try (Reader reader = new FileReader(rankingPath.toFile())) {
                RankingData data = gson.fromJson(reader, RankingData.class);
                if (data != null) {
                    return data;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new RankingData();
    }
    
    /**
     * Saves ranking data to file.
     */
    public void saveRankingData() {
        try (Writer writer = new FileWriter(RANKING_FILE)) {
            gson.toJson(rankingData, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Checks if ranking data exists and is not empty.
     */
    public boolean hasRankingData() {
        return rankingData != null && !rankingData.rankings.isEmpty();
    }
    
    /**
     * Checks if a filename matches homework naming patterns.
     * Patterns: tema, teme, tem, t1-t9, homework, hw (case-insensitive)
     */
    public static boolean isHomeworkFile(String filename) {
        if (filename == null || filename.isEmpty()) {
            return false;
        }
        return HOMEWORK_PATTERN.matcher(filename).matches();
    }
    
    /**
     * Gets the general rankings (all-time points).
     */
    public Map<String, Integer> getGeneralRankings() {
        return new LinkedHashMap<>(rankingData.rankings);
    }
    
    /**
     * Gets rankings for a specific homework period.
     * @param homeworkFile The homework file name
     */
    public Map<String, Integer> getWeeklyRankings(String homeworkFile) {
        Map<String, Integer> weeklyRankings = new LinkedHashMap<>();
        
        Map<String, List<CommitInfo>> homeworkCommits = rankingData.commitHistory.get(homeworkFile);
        if (homeworkCommits != null) {
            for (Map.Entry<String, List<CommitInfo>> entry : homeworkCommits.entrySet()) {
                String person = entry.getKey();
                List<CommitInfo> commits = entry.getValue();
                if (!commits.isEmpty()) {
                    // Use points from first commit
                    weeklyRankings.put(person, commits.get(0).points);
                }
            }
        }
        
        // Sort by points descending
        return sortByValueDescending(weeklyRankings);
    }
    
    /**
     * Gets the top N ranked persons.
     */
    public List<Map.Entry<String, Integer>> getTopRankings(int limit) {
        Map<String, Integer> sorted = sortByValueDescending(rankingData.rankings);
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(sorted.entrySet());
        return entries.subList(0, Math.min(limit, entries.size()));
    }
    
    /**
     * Gets commits for a person in a specific homework period.
     */
    public List<CommitInfo> getCommitsForPerson(String homeworkFile, String person) {
        Map<String, List<CommitInfo>> homeworkCommits = rankingData.commitHistory.get(homeworkFile);
        if (homeworkCommits != null && homeworkCommits.containsKey(person)) {
            return new ArrayList<>(homeworkCommits.get(person));
        }
        return new ArrayList<>();
    }
    
    /**
     * Checks if a person has commits in a homework period.
     */
    public boolean hasCommitsInPeriod(String homeworkFile, String person) {
        return !getCommitsForPerson(homeworkFile, person).isEmpty();
    }
    
    // ==================== Ranking Calculation ====================
    
    /**
     * Refreshes rankings asynchronously without blocking the UI.
     * @param progressCallback Callback for progress updates (0.0 to 1.0)
     * @param onComplete Callback when refresh is complete
     */
    public void refreshRankingsAsync(Consumer<Double> progressCallback, Runnable onComplete) {
        CompletableFuture.runAsync(() -> {
            try {
                refreshRankings(progressCallback);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).thenRun(() -> {
            if (onComplete != null) {
                onComplete.run();
            }
        });
    }
    
    /**
     * Refreshes rankings by fetching commit data from GitHub.
     * Only processes files matching homework naming patterns.
     */
    public void refreshRankings(Consumer<Double> progressCallback) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return;
        }
        
        // Get all homework files with their post dates
        Map<String, Long> cachedFiles = appConfig.getCachedFileMap();
        if (cachedFiles.isEmpty()) {
            return;
        }
        
        // Filter to only homework files
        List<String> homeworkFiles = new ArrayList<>();
        for (String file : cachedFiles.keySet()) {
            if (isHomeworkFile(file)) {
                homeworkFiles.add(file);
            }
        }
        
        System.out.println("Filtered " + cachedFiles.size() + " files to " + homeworkFiles.size() + " homework files");
        
        if (homeworkFiles.isEmpty()) {
            System.out.println("No homework files found matching patterns (tema, teme, tem, t1-9, homework, hw)");
            return;
        }
        
        int totalFiles = homeworkFiles.size();
        int[] processedCount = {0};
        
        // Clear old data for fresh calculation
        rankingData.commitHistory.clear();
        Map<String, Integer> newRankings = new HashMap<>();
        
        for (String homeworkFile : homeworkFiles) {
            Long postTimestamp = cachedFiles.get(homeworkFile);
            if (postTimestamp == null || postTimestamp == 0) {
                processedCount[0]++;
                continue;
            }
            
            LocalDate postDate = Instant.ofEpochMilli(postTimestamp)
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
            LocalDate periodEnd = postDate.plusDays(PERIOD_DAYS);
            
            // Only calculate points for completed periods
            LocalDate today = LocalDate.now();
            if (today.isBefore(periodEnd)) {
                processedCount[0]++;
                if (progressCallback != null) {
                    progressCallback.accept((double) processedCount[0] / totalFiles * 0.8);
                }
                continue;
            }
            
            // Fetch the original post commit OID to exclude it from rankings
            String homeworkPath = appConfig.getHomeworkFolderPath();
            String fullPath = homeworkPath.isEmpty() ? homeworkFile : homeworkPath + "/" + homeworkFile;
            String postCommitOid = fetchOriginalPostCommitOid(fullPath);
            System.out.println("Original post commit for " + homeworkFile + ": " + postCommitOid);
            
            // Fetch commits for this period
            Map<String, List<CommitInfo>> commitsForHomework = fetchCommitsForPeriod(
                repoName, postDate, periodEnd
            );
            
            if (!commitsForHomework.isEmpty()) {
                rankingData.commitHistory.put(homeworkFile, commitsForHomework);
                
                // Calculate points from first commit only
                for (Map.Entry<String, List<CommitInfo>> entry : commitsForHomework.entrySet()) {
                    String person = entry.getKey();
                    List<CommitInfo> commits = entry.getValue();
                    
                    if (!commits.isEmpty()) {
                        // Sort by date and get first commit
                        commits.sort(Comparator.comparing(c -> c.date));
                        
                        // Filter out the original post commit (teacher's upload)
                        CommitInfo firstCommit = null;
                        for (CommitInfo commit : commits) {
                            if (!commit.oid.equals(postCommitOid)) {
                                firstCommit = commit;
                                break;
                            }
                        }
                        
                        // Skip if only the post commit exists (no actual submission)
                        if (firstCommit == null) {
                            continue;
                        }
                        
                        // Calculate points based on days since post
                        LocalDate commitDate = Instant.ofEpochMilli(firstCommit.date)
                            .atZone(ZoneId.systemDefault())
                            .toLocalDate();
                        long daysSincePost = ChronoUnit.DAYS.between(postDate, commitDate);
                        int points = Math.max(0, PERIOD_DAYS - (int) daysSincePost);
                        
                        firstCommit.points = points;
                        
                        // Add to general rankings
                        newRankings.merge(person, points, Integer::sum);
                    }
                }
            }
            
            processedCount[0]++;
            if (progressCallback != null) {
                progressCallback.accept((double) processedCount[0] / totalFiles * 0.8);
            }
        }
        
        // Update rankings
        rankingData.rankings = sortByValueDescending(newRankings);
        rankingData.lastUpdate = System.currentTimeMillis();
        
        if (progressCallback != null) {
            progressCallback.accept(1.0);
        }
        
        // Save to file
        saveRankingData();
        
        // Write debug info to file
        writeDebugInfo(cachedFiles, homeworkFiles);
    }
    
    /**
     * Writes debug information about homework dates and first place commits to a file.
     */
    private void writeDebugInfo(Map<String, Long> cachedFiles, List<String> homeworkFiles) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(DEBUG_FILE))) {
            writer.println("=== RANKING DEBUG INFO ===");
            writer.println("Generated: " + LocalDateTime.now().format(formatter));
            writer.println();
            
            // Sort homework files by post date
            homeworkFiles.sort((a, b) -> {
                Long timeA = cachedFiles.getOrDefault(a, 0L);
                Long timeB = cachedFiles.getOrDefault(b, 0L);
                return timeA.compareTo(timeB);
            });
            
            for (String homeworkFile : homeworkFiles) {
                Long postTimestamp = cachedFiles.get(homeworkFile);
                if (postTimestamp == null || postTimestamp == 0) continue;
                
                LocalDateTime postDateTime = LocalDateTime.ofInstant(
                    Instant.ofEpochMilli(postTimestamp), ZoneId.systemDefault());
                LocalDate postDate = postDateTime.toLocalDate();
                LocalDate periodEnd = postDate.plusDays(PERIOD_DAYS);
                
                writer.println("----------------------------------------");
                writer.println("HOMEWORK: " + homeworkFile);
                writer.println("  Post Date: " + postDateTime.format(formatter));
                writer.println("  Period: " + postDate + " to " + periodEnd + " (5 days)");
                
                // Get commits for this homework
                Map<String, List<CommitInfo>> homeworkCommits = rankingData.commitHistory.get(homeworkFile);
                
                if (homeworkCommits == null || homeworkCommits.isEmpty()) {
                    writer.println("  NO COMMITS FOUND IN PERIOD");
                    writer.println();
                    continue;
                }
                
                // Fetch the original post commit OID to exclude from display (same as ranking calculation)
                String homeworkPath = appConfig.getHomeworkFolderPath();
                String fullPath = homeworkPath.isEmpty() ? homeworkFile : homeworkPath + "/" + homeworkFile;
                String postCommitOid = fetchOriginalPostCommitOid(fullPath);
                writer.println("  Post Commit (excluded): " + (postCommitOid.isEmpty() ? "N/A" : postCommitOid.substring(0, Math.min(7, postCommitOid.length()))));
                
                // Find first place for this homework (highest points / earliest commit)
                List<Map.Entry<String, CommitInfo>> firstCommits = new ArrayList<>();
                for (Map.Entry<String, List<CommitInfo>> entry : homeworkCommits.entrySet()) {
                    String person = entry.getKey();
                    List<CommitInfo> commits = entry.getValue();
                    if (!commits.isEmpty()) {
                        // Sort and get first commit that is NOT the post commit
                        commits.sort(Comparator.comparing(c -> c.date));
                        CommitInfo firstCommit = null;
                        for (CommitInfo commit : commits) {
                            if (!commit.oid.equals(postCommitOid)) {
                                firstCommit = commit;
                                break;
                            }
                        }
                        // Only add if there's a non-post commit
                        if (firstCommit != null) {
                            firstCommits.add(new AbstractMap.SimpleEntry<>(person, firstCommit));
                        }
                    }
                }
                
                // Sort by points (descending), then by date (ascending)
                firstCommits.sort((a, b) -> {
                    int pointsCompare = Integer.compare(b.getValue().points, a.getValue().points);
                    if (pointsCompare != 0) return pointsCompare;
                    return Long.compare(a.getValue().date, b.getValue().date);
                });
                
                writer.println("  RANKINGS FOR THIS HOMEWORK (Top 10):");
                int rank = 1;
                boolean foundSpecialUser = false;
                final String SPECIAL_USER = "Gurau-Andrei-Eduard";
                
                for (Map.Entry<String, CommitInfo> entry : firstCommits) {
                    String person = entry.getKey();
                    CommitInfo commit = entry.getValue();
                    LocalDateTime commitDateTime = LocalDateTime.ofInstant(
                        Instant.ofEpochMilli(commit.date), ZoneId.systemDefault());
                    long daysSincePost = ChronoUnit.DAYS.between(postDate, commitDateTime.toLocalDate());
                    
                    if (person.equals(SPECIAL_USER)) {
                        foundSpecialUser = true;
                    }
                    
                    if (rank <= 10) {
                        writer.println("    " + rank + ". " + person + (person.equals(SPECIAL_USER) ? " <<<" : ""));
                        writer.println("       Commit: " + commit.oid.substring(0, 7) + " - " + truncateMessage(commit.message, 40));
                        writer.println("       Commit Date: " + commitDateTime.format(formatter));
                        writer.println("       Days after post: " + daysSincePost + " -> " + commit.points + " points");
                    }
                    
                    rank++;
                }
                
                // Special mention for Gurau-Andrei-Eduard if not in top 10
                if (!foundSpecialUser) {
                    writer.println("    --- " + SPECIAL_USER + " NOT FOUND in this homework period ---");
                } else {
                    // Find and show their entry if they were beyond top 10
                    int specialRank = 1;
                    for (Map.Entry<String, CommitInfo> entry : firstCommits) {
                        if (entry.getKey().equals(SPECIAL_USER) && specialRank > 10) {
                            CommitInfo commit = entry.getValue();
                            LocalDateTime commitDateTime = LocalDateTime.ofInstant(
                                Instant.ofEpochMilli(commit.date), ZoneId.systemDefault());
                            long daysSincePost = ChronoUnit.DAYS.between(postDate, commitDateTime.toLocalDate());
                            writer.println("    ...");
                            writer.println("    " + specialRank + ". " + SPECIAL_USER + " <<<");
                            writer.println("       Commit: " + commit.oid.substring(0, 7) + " - " + truncateMessage(commit.message, 40));
                            writer.println("       Commit Date: " + commitDateTime.format(formatter));
                            writer.println("       Days after post: " + daysSincePost + " -> " + commit.points + " points");
                        }
                        specialRank++;
                    }
                }
                writer.println();
            }
            
            // Write general rankings summary
            writer.println("========================================");
            writer.println("GENERAL RANKINGS (Total Points)");
            writer.println("========================================");
            int rank = 1;
            for (Map.Entry<String, Integer> entry : rankingData.rankings.entrySet()) {
                writer.println(rank + ". " + entry.getKey() + " - " + entry.getValue() + " pts");
                rank++;
                if (rank > 20) break; // Top 20
            }
            
            // Detailed breakdown for special user
            final String SPECIAL_USER = "Gurau-Andrei-Eduard";
            writer.println();
            writer.println("========================================");
            writer.println("DETAILED BREAKDOWN FOR: " + SPECIAL_USER);
            writer.println("========================================");
            int totalPoints = 0;
            for (String hwFile : homeworkFiles) {
                Map<String, List<CommitInfo>> hwCommits = rankingData.commitHistory.get(hwFile);
                if (hwCommits != null && hwCommits.containsKey(SPECIAL_USER)) {
                    List<CommitInfo> commits = hwCommits.get(SPECIAL_USER);
                    if (commits != null && !commits.isEmpty()) {
                        // Find the commit that gave points (the one with points > 0)
                        for (CommitInfo c : commits) {
                            if (c.points > 0) {
                                writer.println(hwFile + ": " + c.points + " pts (commit " + c.oid.substring(0,7) + ")");
                                totalPoints += c.points;
                            }
                        }
                        // If no commits with points, show what they have
                        boolean hasPointCommit = commits.stream().anyMatch(c -> c.points > 0);
                        if (!hasPointCommit) {
                            CommitInfo first = commits.get(0);
                            writer.println(hwFile + ": 0 pts (only post commit " + first.oid.substring(0,7) + ")");
                        }
                    }
                } else {
                    writer.println(hwFile + ": NOT FOUND");
                }
            }
            writer.println("Total calculated from breakdown: " + totalPoints + " pts");
            writer.println("Total in rankings: " + rankingData.rankings.getOrDefault(SPECIAL_USER, 0) + " pts");
            
            System.out.println("Debug info written to: " + DEBUG_FILE);
            
        } catch (IOException e) {
            System.err.println("Failed to write debug file: " + e.getMessage());
        }
    }
    
    private String truncateMessage(String message, int maxLen) {
        if (message == null) return "";
        String firstLine = message.split("\n")[0];
        if (firstLine.length() > maxLen) {
            return firstLine.substring(0, maxLen - 3) + "...";
        }
        return firstLine;
    }
    
    /**
     * Fetches the original post commit OID for a file on the main branch.
     * This is the OLDEST commit that introduced the file (teacher's upload).
     * @param filePath Full path to the file (including homework folder)
     * @return The commit OID, or empty string if not found
     */
    private String fetchOriginalPostCommitOid(String filePath) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return "";
        }
        
        try {
            // URL-encode the path to handle spaces and special characters
            String encodedPath = java.net.URLEncoder.encode(filePath, "UTF-8")
                .replace("+", "%20");
            
            // Fetch from main branch specifically, get the OLDEST commit (last in the array)
            String apiUrl = "repos/" + repoName + "/commits?path=" + encodedPath + "&sha=main&per_page=100";
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", apiUrl, "--jq", ".[-1].sha"  // .[-1] gets the LAST (oldest) commit's SHA
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line = reader.readLine();
                if (line != null && !line.trim().isEmpty()) {
                    return line.trim().replaceAll("\"", "");
                }
            }
            process.waitFor();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    
    /**
     * Fetches commits from all branches within a date range using GraphQL.
     */
    private Map<String, List<CommitInfo>> fetchCommitsForPeriod(
            String repoName, LocalDate startDate, LocalDate endDate) {
        
        Map<String, List<CommitInfo>> result = new HashMap<>();
        
        String[] repoParts = repoName.split("/");
        if (repoParts.length != 2) {
            return result;
        }
        String owner = repoParts[0];
        String repo = repoParts[1];
        
        // Build GraphQL query
        String query = buildGraphQLQuery(owner, repo, startDate, endDate);
        
        // Execute with retry
        String response = executeGraphQLWithRetry(query);
        if (response == null) {
            return result;
        }
        
        // Parse response
        result = parseGraphQLResponse(response);
        
        return result;
    }
    
    private String buildGraphQLQuery(String owner, String repo, LocalDate startDate, LocalDate endDate) {
        String since = startDate.atStartOfDay(ZoneId.of("UTC")).toInstant().toString();
        String until = endDate.atTime(23, 59, 59).atZone(ZoneId.of("UTC")).toInstant().toString();
        
        // Note: owner and repo are already strings, GraphQL requires them in quotes
        // The repo name may contain special characters like hyphens followed by numbers
        return String.format(
            "query { " +
            "  repository(owner: \\\"%s\\\", name: \\\"%s\\\") { " +
            "    refs(refPrefix: \\\"refs/heads/\\\", first: 100) { " +
            "      nodes { " +
            "        name " +
            "        target { " +
            "          ... on Commit { " +
            "            history(since: \\\"%s\\\", until: \\\"%s\\\") { " +
            "              nodes { " +
            "                oid " +
            "                message " +
            "                committedDate " +
            "              } " +
            "            } " +
            "          } " +
            "        } " +
            "      } " +
            "    } " +
            "  } " +
            "}",
            owner, repo, since, until
        );
    }
    
    private String executeGraphQLWithRetry(String query) {
        for (int attempt = 0; attempt < MAX_RETRIES; attempt++) {
            try {
                ProcessBuilder processBuilder = new ProcessBuilder(
                    "gh", "api", "graphql", "-f", "query=" + query
                );
                processBuilder.redirectErrorStream(true);
                Process process = processBuilder.start();
                
                StringBuilder output = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line);
                    }
                }
                
                int exitCode = process.waitFor();
                String response = output.toString();
                
                if (exitCode == 0) {
                    return response;
                }
                
                // Check for rate limit
                if (response.contains("rate limit") || response.contains("403")) {
                    System.err.println("Rate limited, waiting " + RETRY_DELAYS[attempt] + "ms...");
                    Thread.sleep(RETRY_DELAYS[attempt]);
                    continue;
                }
                
                // Other error - don't retry
                System.err.println("GraphQL error: " + response);
                return null;
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            } catch (IOException e) {
                System.err.println("IO error: " + e.getMessage());
                if (attempt < MAX_RETRIES - 1) {
                    try {
                        Thread.sleep(RETRY_DELAYS[attempt]);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return null;
                    }
                }
            }
        }
        return null;
    }
    
    @SuppressWarnings("unchecked")
    private Map<String, List<CommitInfo>> parseGraphQLResponse(String response) {
        Map<String, List<CommitInfo>> result = new HashMap<>();
        
        try {
            Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
            Map<String, Object> root = gson.fromJson(response, mapType);
            
            if (root == null || !root.containsKey("data")) {
                return result;
            }
            
            Map<String, Object> data = (Map<String, Object>) root.get("data");
            Map<String, Object> repository = (Map<String, Object>) data.get("repository");
            if (repository == null) return result;
            
            Map<String, Object> refs = (Map<String, Object>) repository.get("refs");
            if (refs == null) return result;
            
            List<Map<String, Object>> nodes = (List<Map<String, Object>>) refs.get("nodes");
            if (nodes == null) return result;
            
            for (Map<String, Object> branch : nodes) {
                String branchName = (String) branch.get("name");
                if (branchName == null || branchName.equals("main") || branchName.equals("master")) {
                    continue; // Skip main/master branches
                }
                
                Map<String, Object> target = (Map<String, Object>) branch.get("target");
                if (target == null) continue;
                
                Map<String, Object> history = (Map<String, Object>) target.get("history");
                if (history == null) continue;
                
                List<Map<String, Object>> commits = (List<Map<String, Object>>) history.get("nodes");
                if (commits == null || commits.isEmpty()) continue;
                
                List<CommitInfo> commitInfos = new ArrayList<>();
                for (Map<String, Object> commit : commits) {
                    String oid = (String) commit.get("oid");
                    String message = (String) commit.get("message");
                    String dateStr = (String) commit.get("committedDate");
                    
                    long timestamp = 0;
                    try {
                        timestamp = Instant.parse(dateStr).toEpochMilli();
                    } catch (Exception e) {
                        // Skip invalid date
                    }
                    
                    commitInfos.add(new CommitInfo(oid, message, timestamp, 0));
                }
                
                if (!commitInfos.isEmpty()) {
                    // Use branch name as person identifier
                    result.put(branchName, commitInfos);
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return result;
    }
    
    // ==================== File Operations for Copying ====================
    
    // Cached user branch to avoid repeated API calls
    private String cachedUserBranch = null;
    
    /**
     * Finds the user's branch in the repository by matching their GitHub name or login.
     * @return The branch name, or null if not found
     */
    public String findUserBranch() {
        if (cachedUserBranch != null) {
            return cachedUserBranch;
        }
        
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return null;
        }
        
        try {
            // Step 1: Get user details (login and name)
            ProcessBuilder userPb = new ProcessBuilder(
                "gh", "api", "/user"
            );
            userPb.redirectErrorStream(true);
            Process userProcess = userPb.start();
            
            StringBuilder userJson = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(userProcess.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    userJson.append(line);
                }
            }
            userProcess.waitFor();
            
            Type mapType = new TypeToken<Map<String, Object>>(){}.getType();
            Map<String, Object> userData = gson.fromJson(userJson.toString(), mapType);
            
            String login = (String) userData.get("login");
            String name = (String) userData.get("name");
            
            // Normalize strings for comparison (remove non-alphanumeric, lowercase)
            String normLogin = login != null ? login.replaceAll("[^a-zA-Z0-9]", "").toLowerCase() : "";
            String normName = name != null ? name.replaceAll("[^a-zA-Z0-9]", "").toLowerCase() : "";
            
            // Step 2: Get all branches
            // Use pagination to ensure we get all branches
            List<String> branches = new ArrayList<>();
            ProcessBuilder branchesPb = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/branches", "--paginate", "--jq", ".[].name"
            );
            branchesPb.redirectErrorStream(true);
            Process branchesProcess = branchesPb.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(branchesProcess.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.trim().isEmpty()) {
                        branches.add(line.trim());
                    }
                }
            }
            branchesProcess.waitFor();
            
            // Step 3: Find a match
            // First priority: Name match
            if (!normName.isEmpty()) {
                for (String branch : branches) {
                    String normBranch = branch.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
                    if (normBranch.equals(normName)) {
                        cachedUserBranch = branch;
                        return branch;
                    }
                }
            }
            
            // Second priority: Login match
            if (!normLogin.isEmpty()) {
                for (String branch : branches) {
                    String normBranch = branch.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
                    if (normBranch.equals(normLogin)) {
                        cachedUserBranch = branch;
                        return branch;
                    }
                }
            }
            
            // Third priority: Login contains branch or branch contains login
            if (!normLogin.isEmpty()) {
                for (String branch : branches) {
                    String normBranch = branch.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
                    if (normBranch.contains(normLogin) || normLogin.contains(normBranch)) {
                         // Only pick if length difference is small to avoid false positives
                         if (Math.abs(normBranch.length() - normLogin.length()) < 5) {
                             cachedUserBranch = branch;
                             return branch;
                         }
                    }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Checks if a branch exists in the repository.
     * @param branchName The branch name to check
     * @return true if branch exists, false otherwise
     */
    public boolean checkBranchExists(String branchName) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty() || branchName == null) {
            return false;
        }
        
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/ref/heads/" + branchName
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            int exitCode = process.waitFor();
            return exitCode == 0;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * Checks if a file exists on a specific branch.
     * @param filePath The file path
     * @param branch The branch name
     * @return true if file exists, false otherwise
     */
    public boolean checkFileExistsOnBranch(String filePath, String branch) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return false;
        }
        
        try {
            String encodedPath = java.net.URLEncoder.encode(filePath, "UTF-8").replace("+", "%20");
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/contents/" + encodedPath + "?ref=" + branch
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            int exitCode = process.waitFor();
            return exitCode == 0;
            
        } catch (Exception e) {
            // File doesn't exist or error
        }
        return false;
    }
    
    /**
     * Resolves a unique filename on the target branch.
     * If file exists, appends _2, _3, etc. until finding an unused name.
     * @param filePath The original file path
     * @param branch The target branch
     * @return A unique file path that doesn't exist on the branch
     */
    public String resolveUniqueFilename(String filePath, String branch) {
        if (!checkFileExistsOnBranch(filePath, branch)) {
            return filePath;
        }
        
        // Extract name and extension
        int lastDot = filePath.lastIndexOf('.');
        int lastSlash = Math.max(filePath.lastIndexOf('/'), filePath.lastIndexOf('\\'));
        
        String basePath;
        String extension;
        
        if (lastDot > lastSlash) {
            basePath = filePath.substring(0, lastDot);
            extension = filePath.substring(lastDot);
        } else {
            basePath = filePath;
            extension = "";
        }
        
        // Try _2, _3, etc.
        for (int i = 2; i <= 100; i++) {
            String newPath = basePath + "_" + i + extension;
            if (!checkFileExistsOnBranch(newPath, branch)) {
                return newPath;
            }
        }
        
        // Fallback with timestamp
        return basePath + "_" + System.currentTimeMillis() + extension;
    }
    
    /**
     * Fetches the blob SHA for a file at a specific ref.
     * @param filePath The file path
     * @param ref The git ref (commit OID or branch name)
     * @return The blob SHA, or null if not found
     */
    public String fetchFileBlobSha(String filePath, String ref) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return null;
        }
        
        try {
            String encodedPath = java.net.URLEncoder.encode(filePath, "UTF-8").replace("+", "%20");
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/contents/" + encodedPath + "?ref=" + ref,
                "--jq", ".sha"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line);
                }
            }
            
            int exitCode = process.waitFor();
            String result = output.toString().trim().replaceAll("\"", "");
            
            if (exitCode == 0 && result.length() == 40) {
                return result;
            } else {
                // Not necessarily an error, file might not exist or other issue
                return null;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Result class for copy operation.
     */
    public static class CopyResult {
        public final boolean success;
        public final String message;
        public final List<String> copiedFiles;
        public final List<String> renamedFiles; // Original -> New name mapping info
        
        public CopyResult(boolean success, String message, List<String> copiedFiles, List<String> renamedFiles) {
            this.success = success;
            this.message = message;
            this.copiedFiles = copiedFiles != null ? copiedFiles : new ArrayList<>();
            this.renamedFiles = renamedFiles != null ? renamedFiles : new ArrayList<>();
        }
    }
    
    /**
     * Copies files from a source commit to the user's branch using Git Data API.
     * Creates a single commit with all files.
     * 
     * @param sourceOid The source commit OID
     * @param filePaths List of file paths to copy
     * @param targetBranch The target branch name (user's branch)
     * @param commitMessage The commit message
     * @return CopyResult with success status and details
     */
    public CopyResult copyFilesToUserBranch(String sourceOid, List<String> filePaths, 
                                            String targetBranch, String commitMessage) {
        String repoName = appConfig.getSelectedRepo();
        if (repoName == null || repoName.isEmpty()) {
            return new CopyResult(false, "No repository selected", null, null);
        }
        
        // Check if target branch exists
        if (!checkBranchExists(targetBranch)) {
            return new CopyResult(false, 
                "Branch '" + targetBranch + "' does not exist.\n\n" +
                "Please create your branch first on GitHub before copying files.", 
                null, null);
        }
        
        List<String> copiedFiles = new ArrayList<>();
        List<String> renamedFiles = new ArrayList<>();
        
        try {
            // Step 1: Get the HEAD SHA of the target branch
            String headSha = getBranchHeadSha(targetBranch);
            if (headSha == null) {
                return new CopyResult(false, "Could not get HEAD of branch " + targetBranch, null, null);
            }
            
            // Step 2: Get the tree SHA from the HEAD commit
            String baseTreeSha = getCommitTreeSha(headSha);
            if (baseTreeSha == null) {
                return new CopyResult(false, "Could not get tree of HEAD commit", null, null);
            }
            
            // Step 3: Build tree entries for all files
            List<Map<String, String>> treeEntries = new ArrayList<>();
            
            for (String filePath : filePaths) {
                // Get blob SHA from source
                String blobSha = fetchFileBlobSha(filePath, sourceOid);
                if (blobSha == null) {
                    System.err.println("Could not get blob SHA for: " + filePath);
                    continue;
                }
                
                // Resolve unique filename (handles duplicates with _2, _3, etc.)
                String targetPath = resolveUniqueFilename(filePath, targetBranch);
                
                if (!targetPath.equals(filePath)) {
                    renamedFiles.add(filePath + " → " + targetPath);
                }
                
                Map<String, String> entry = new HashMap<>();
                entry.put("path", targetPath);
                entry.put("mode", "100644"); // Regular file
                entry.put("type", "blob");
                entry.put("sha", blobSha);
                treeEntries.add(entry);
                
                copiedFiles.add(targetPath);
            }
            
            if (treeEntries.isEmpty()) {
                return new CopyResult(false, "No files could be processed for copying", null, null);
            }
            
            // Step 4: Create new tree
            String newTreeSha = createTree(baseTreeSha, treeEntries);
            if (newTreeSha == null) {
                return new CopyResult(false, "Failed to create new tree", null, null);
            }
            
            // Step 5: Create new commit
            String newCommitSha = createCommit(newTreeSha, headSha, commitMessage);
            if (newCommitSha == null) {
                return new CopyResult(false, "Failed to create commit", null, null);
            }
            
            // Step 6: Update branch reference
            String updateError = updateBranchRef(targetBranch, newCommitSha);
            if (updateError != null) {
                return new CopyResult(false, "Failed to update branch reference: " + updateError, null, null);
            }
            
            return new CopyResult(true, 
                "Successfully copied " + copiedFiles.size() + " file(s) to branch " + targetBranch,
                copiedFiles, renamedFiles);
            
        } catch (Exception e) {
            e.printStackTrace();
            return new CopyResult(false, "Error: " + e.getMessage(), null, null);
        }
    }
    
    /**
     * Gets the HEAD SHA of a branch.
     */
    private String getBranchHeadSha(String branch) {
        String repoName = appConfig.getSelectedRepo();
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/ref/heads/" + branch,
                "--jq", ".object.sha"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line);
                }
            }
            
            int exitCode = process.waitFor();
            String result = output.toString().trim().replaceAll("\"", "");
            
            if (exitCode == 0 && result.length() == 40) {
                return result;
            } else {
                System.err.println("Failed to get branch HEAD. Exit code: " + exitCode + ", Output: " + result);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Gets the tree SHA from a commit.
     */
    private String getCommitTreeSha(String commitSha) {
        String repoName = appConfig.getSelectedRepo();
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/commits/" + commitSha,
                "--jq", ".tree.sha"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line);
                }
            }
            
            int exitCode = process.waitFor();
            String result = output.toString().trim().replaceAll("\"", "");
            
            if (exitCode == 0 && result.length() == 40) {
                return result;
            } else {
                System.err.println("Failed to get commit tree. Exit code: " + exitCode + ", Output: " + result);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Creates a new tree with the given entries.
     */
    private String createTree(String baseTreeSha, List<Map<String, String>> entries) {
        String repoName = appConfig.getSelectedRepo();
        try {
            // Construct the full JSON body
            Map<String, Object> body = new HashMap<>();
            body.put("base_tree", baseTreeSha);
            body.put("tree", entries);
            
            String jsonBody = gson.toJson(body);
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/trees",
                "--input", "-",
                "--jq", ".sha"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            // Write JSON to stdin
            try (OutputStream os = process.getOutputStream();
                 PrintWriter writer = new PrintWriter(new OutputStreamWriter(os, "UTF-8"))) {
                writer.write(jsonBody);
            }
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line);
                }
            }
            
            int exitCode = process.waitFor();
            String result = output.toString().trim().replaceAll("\"", "");
            
            if (exitCode == 0 && result.length() == 40) {
                return result;
            } else {
                System.err.println("Failed to create tree. Exit code: " + exitCode + ", Output: " + result);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Creates a new commit.
     */
    private String createCommit(String treeSha, String parentSha, String message) {
        String repoName = appConfig.getSelectedRepo();
        try {
            // Construct the full JSON body
            Map<String, Object> body = new HashMap<>();
            body.put("message", message);
            body.put("tree", treeSha);
            body.put("parents", Collections.singletonList(parentSha));
            
            String jsonBody = gson.toJson(body);
            
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/commits",
                "--input", "-",
                "--jq", ".sha"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            // Write JSON to stdin
            try (OutputStream os = process.getOutputStream();
                 PrintWriter writer = new PrintWriter(new OutputStreamWriter(os, "UTF-8"))) {
                writer.write(jsonBody);
            }
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line);
                }
            }
            
            int exitCode = process.waitFor();
            String result = output.toString().trim().replaceAll("\"", "");
            
            if (exitCode == 0 && result.length() == 40) {
                return result;
            } else {
                System.err.println("Failed to create commit. Exit code: " + exitCode + ", Output: " + result);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * Updates a branch reference to point to a new commit.
     * @return null if successful, error message otherwise
     */
    private String updateBranchRef(String branch, String commitSha) {
        String repoName = appConfig.getSelectedRepo();
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/git/refs/heads/" + branch,
                "-X", "PATCH",
                "-f", "sha=" + commitSha
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }
            
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                return null;
            } else {
                return output.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Exception: " + e.getMessage();
        }
    }
    
    /**
     * Fetches the list of files in a specific commit.
     * @param oid The commit OID
     * @return List of filenames in the commit
     */
    public List<String> fetchFilesInCommit(String oid) {
        List<String> files = new ArrayList<>();
        String repoName = appConfig.getSelectedRepo();
        
        if (repoName == null || repoName.isEmpty() || oid == null) {
            return files;
        }
        
        try {
            ProcessBuilder processBuilder = new ProcessBuilder(
                "gh", "api", "repos/" + repoName + "/commits/" + oid,
                "--jq", ".files[].filename"
            );
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.trim().isEmpty()) {
                        files.add(line.trim());
                    }
                }
            }
            process.waitFor();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return files;
    }
    
    // ==================== Helper Methods ====================
    
    private <K, V extends Comparable<? super V>> Map<K, V> sortByValueDescending(Map<K, V> map) {
        List<Map.Entry<K, V>> list = new ArrayList<>(map.entrySet());
        list.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));
        
        Map<K, V> result = new LinkedHashMap<>();
        for (Map.Entry<K, V> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }
    
    // ==================== Inner Classes ====================
    
    /**
     * Token validation status.
     */
    public static class TokenStatus {
        public final boolean isValid;
        public final boolean hasRepoScope;
        public final String errorMessage;
        
        public TokenStatus(boolean isValid, boolean hasRepoScope, String errorMessage) {
            this.isValid = isValid;
            this.hasRepoScope = hasRepoScope;
            this.errorMessage = errorMessage;
        }
    }
    
    /**
     * Commit information.
     */
    public static class CommitInfo {
        public String oid;
        public String message;
        public long date;
        public int points;
        
        public CommitInfo() {}
        
        public CommitInfo(String oid, String message, long date, int points) {
            this.oid = oid;
            this.message = message;
            this.date = date;
            this.points = points;
        }
    }
    
    /**
     * Complete ranking data structure.
     */
    public static class RankingData {
        public Map<String, Integer> rankings = new LinkedHashMap<>(); // person -> total points
        public Map<String, Map<String, List<CommitInfo>>> commitHistory = new HashMap<>(); // homework -> person -> commits
        public long lastUpdate = 0;
        
        public RankingData() {}
    }
}
