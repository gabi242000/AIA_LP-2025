package rob.icu.e2ee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E2EeApplicationTests {

    @Test
    void contextLoads() {
    }

}
