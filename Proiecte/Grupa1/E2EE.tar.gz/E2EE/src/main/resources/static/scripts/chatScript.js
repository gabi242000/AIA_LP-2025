let stompClient = null;
let currentUserId = null;
let currentUsername = null;
let textEncoder = new TextEncoder();
let textDecoder = new TextDecoder();
const AUTO_KEY_STORAGE = 'e2ee_auto_key';

const pendingKeyExchanges = new Map();
const sharedKeysStorage = 'e2ee_shared_keys';

function getSharedKeys() {
    try {
        const stored = localStorage.getItem(sharedKeysStorage);
        return stored ? JSON.parse(stored) : {};
    } catch (e) {
        return {};
    }
}

function setSharedKey(username, keyBase64) {
    try {
        const keys = getSharedKeys();
        keys[username] = keyBase64;
        localStorage.setItem(sharedKeysStorage, JSON.stringify(keys));
    } catch (e) {
        console.warn('Failed to store shared key:', e);
    }
}

function getSharedKeyForUser(username) {
    const keys = getSharedKeys();
    return keys[username] || null;
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

window.onload = function() {
    currentUserId = getCookie('userId');
    currentUsername = getCookie('username');

    try { tryImportKeyFromUrlFragment(); } catch (e) { console.warn('Key import failed', e); }

    try { populateKeyFieldWithAutoKey(); } catch (e) { console.warn('Auto-key init failed', e); }

    try {
        const params = new URLSearchParams(window.location.search);
        const withParam = params.get('with');
        if (withParam) {
            const receiverEl = document.getElementById('receiver');
            if (receiverEl) receiverEl.value = withParam;
        }
    } catch (e) { /* noop */ }

    if (!currentUserId) {
        showError('Not logged in. Please log in first.');
        document.getElementById('sendBtn').disabled = true;
        return;
    }

    connect();
};

function connect() {
    updateStatus('Connecting...', false);

    const socket = new SockJS('/ws');
    stompClient = Stomp.over(socket);


    stompClient.connect({ username: (currentUsername || currentUserId) }, function(frame) {
        console.log('Connected: ' + frame);
        updateStatus('Connected as: ' + (currentUsername || currentUserId), true);


        stompClient.subscribe('/topic/messages.' + currentUserId, function(msg) {
            const body = JSON.parse(msg.body);
            processAndShowMessage(body.sender, body.content, false);
        });

        if (currentUsername && currentUsername !== currentUserId) {
            stompClient.subscribe('/topic/messages.' + currentUsername, function(msg) {
                const body = JSON.parse(msg.body);
                processAndShowMessage(body.sender, body.content, false);
            });
        }

        stompClient.subscribe('/topic/key-exchange.' + currentUserId, function(msg) {
            handleKeyExchangeMessage(JSON.parse(msg.body));
        });
        if (currentUsername && currentUsername !== currentUserId) {
            stompClient.subscribe('/topic/key-exchange.' + currentUsername, function(msg) {
                handleKeyExchangeMessage(JSON.parse(msg.body));
            });
        }
    }, function(error) {
        console.error('Connection error:', error);
        updateStatus('Connection failed. Please refresh the page.', false);
        showError('Failed to connect to chat server.');
    });
}

async function sendMessage() {
    const receiver = document.getElementById('receiver').value.trim();
    const content = document.getElementById('message').value.trim();
    const passphrase = getPassphrase();

    if (!receiver) {
        showError('Please enter a recipient.');
        return;
    }

    if (!content) {
        showError('Please enter a message.');
        return;
    }

    if (!stompClient || !stompClient.connected) {
        showError('Not connected to chat server.');
        return;
    }

    try {
        const encrypted = await encryptE2EE(content, passphrase);

        stompClient.send("/app/private-message", { username: (currentUsername || currentUserId) }, JSON.stringify({
            sender: currentUserId,
            receiver: receiver,
            content: encrypted
        }));

        showMessage('You', content, true);

        document.getElementById('message').value = '';
        hideError();
    } catch (error) {
        console.error('Error sending message:', error);
        showError('Failed to send message.');
    }
}

async function loadConversation() {
    const receiver = document.getElementById('receiver').value.trim();
    if (!receiver) {
        showError('Please enter who to load conversation with.');
        return;
    }
    hideError();

    try {
        const resp = await fetch(`/api/messages/conversation?with=${encodeURIComponent(receiver)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            credentials: 'same-origin'
        });
        if (!resp.ok) {
            showError('Failed to load conversation.');
            return;
        }
        const data = await resp.json();

        const messagesDiv = document.getElementById('messages');
        messagesDiv.innerHTML = '';

        const me = (currentUsername || currentUserId);
        for (const msg of data) {
            const isSent = (msg.sender === me);
            await processAndShowMessage(isSent ? 'You' : msg.sender, msg.content, isSent);
        }
    } catch (e) {
        console.error('Error loading conversation:', e);
        showError('Error loading conversation.');
    }
}

function showMessage(sender, content, isSent) {
    const messagesDiv = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + (isSent ? 'sent' : 'received');

    const senderDiv = document.createElement('div');
    senderDiv.className = 'message-sender';
    senderDiv.textContent = sender;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = content;

    messageDiv.appendChild(senderDiv);
    messageDiv.appendChild(contentDiv);
    messagesDiv.appendChild(messageDiv);

    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function updateStatus(message, isConnected) {
    const statusDiv = document.getElementById('status');
    statusDiv.textContent = message;
    if (isConnected) {
        statusDiv.classList.add('connected');
    } else {
        statusDiv.classList.remove('connected');
    }
}

function showError(message) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function hideError() {
    const errorDiv = document.getElementById('error');
    errorDiv.style.display = 'none';
}

function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

//format: "E2EE1:" + base64(salt) + ":" + base64(iv) + ":" + base64(ciphertext)

function getPassphrase() {
    const el = document.getElementById('passphrase');
    const v = (el?.value || '').trim();
    if (v) return v;
    const auto = getOrCreateAutoKey();
    if (el) el.value = auto;
    return auto;
}

function getOrCreateAutoKey() {
    try {
        let key = localStorage.getItem(AUTO_KEY_STORAGE);
        if (!key) {
            const kb = randomBytes(32);
            key = toBase64(kb);
            localStorage.setItem(AUTO_KEY_STORAGE, key);
        }
        return key;
    } catch (e) {
        const kb = randomBytes(32);
        return toBase64(kb);
    }
}

function populateKeyFieldWithAutoKey() {
    const el = document.getElementById('passphrase');
    if (el) {
        const key = getOrCreateAutoKey();
        el.value = key;
        el.placeholder = '(auto-generated)';
        el.title = 'This key is generated in your browser. Share it securely with your chat partner to decrypt messages.';
    }
}

function tryImportKeyFromUrlFragment() {
    const hash = window.location.hash || '';
    if (!hash || hash.length < 2) return;
    const frag = hash.startsWith('#') ? hash.substring(1) : hash;
    const params = new URLSearchParams(frag);
    const maybeKey = params.get('e2eeKey') || params.get('key');
    if (!maybeKey) return;
    try {
        const bytes = fromBase64(decodeURIComponent(maybeKey));
        if (!(bytes instanceof Uint8Array) || bytes.length < 16) {
            console.warn('Fragment key present but invalid length');
        } else {
            const b64 = toBase64(bytes);
            localStorage.setItem(AUTO_KEY_STORAGE, b64);
            const el = document.getElementById('passphrase');
            if (el) el.value = b64;
            try { history.replaceState(null, '', window.location.pathname + window.location.search); } catch (e) {}
            updateStatus('Imported chat key from invite link', false);
        }
    } catch (e) {
        console.warn('Failed to import key from URL fragment:', e);
    }
}

async function copyToClipboard(text) {
    try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(text);
            return true;
        }
    } catch (_) {}

    try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        return true;
    } catch (_) { return false; }
}

async function copyCurrentKey() {
    const key = getPassphrase();
    if (!key) { showError('No key available to copy.'); return; }
    const ok = await copyToClipboard(key);
    if (ok) {
        hideError();
        updateStatus('Key copied to clipboard', false);
    } else {
        showError('Failed to copy key');
    }
}

async function copyInviteLink() {
    const key = getPassphrase();
    if (!key) { showError('No key available for invite link.'); return; }
    const url = new URL(window.location.href);
    const recvEl = document.getElementById('receiver');
    const recv = (recvEl?.value || '').trim();
    if (recv) url.searchParams.set('with', recv);
    url.hash = 'e2eeKey=' + encodeURIComponent(key);
    const ok = await copyToClipboard(url.toString());
    if (ok) {
        hideError();
        updateStatus('Invite link copied. Share it securely.', false);
    } else {
        showError('Failed to copy invite link');
    }
}

async function deriveAesKey(passphrase, saltBytes) {
    const keyMaterial = await crypto.subtle.importKey(
        'raw',
        textEncoder.encode(passphrase),
        { name: 'PBKDF2' },
        false,
        ['deriveKey']
    );
    return crypto.subtle.deriveKey(
        {
            name: 'PBKDF2',
            salt: saltBytes,
            iterations: 100000,
            hash: 'SHA-256'
        },
        keyMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
    );
}

function toBase64(bytes) {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
        const sub = bytes.subarray(i, i + chunk);
        binary += String.fromCharCode.apply(null, sub);
    }
    return btoa(binary);
}

function fromBase64(b64) {
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
}

function randomBytes(length) {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return bytes;
}

async function encryptE2EE(plaintext, passphrase) {
    const salt = randomBytes(16);
    const iv = randomBytes(12);
    const key = await deriveAesKey(passphrase, salt);
    const cipherBuf = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        key,
        textEncoder.encode(plaintext)
    );
    const ctBytes = new Uint8Array(cipherBuf);
    return `E2EE1:${toBase64(salt)}:${toBase64(iv)}:${toBase64(ctBytes)}`;
}

async function decryptE2EE(envelope, passphrase) {
    if (typeof envelope !== 'string' || !envelope.startsWith('E2EE1:')) {
        return { plaintext: envelope, encrypted: false, ok: true };
    }
    const parts = envelope.split(':');
    if (parts.length !== 4) {
        return { plaintext: '[Encrypted message: invalid format]', encrypted: true, ok: false };
    }
    try {
        const salt = fromBase64(parts[1]);
        const iv = fromBase64(parts[2]);
        const ct = fromBase64(parts[3]);
        const key = await deriveAesKey(passphrase, salt);
        const plainBuf = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv },
            key,
            ct
        );
        const plaintext = textDecoder.decode(new Uint8Array(plainBuf));
        return { plaintext, encrypted: true, ok: true };
    } catch (e) {
        return { plaintext: '[Encrypted message: wrong passphrase]', encrypted: true, ok: false };
    }
}

async function processAndShowMessage(sender, content, isSent) {
    const passphrase = getPassphrase();
    const result = await decryptE2EE(content, passphrase);
    showMessage(sender, result.plaintext, isSent);
}

//
// ECDH Key Exchange for passing keys between users
//

async function generateECDHKeyPair() {
    const keyPair = await crypto.subtle.generateKey(
        { name: 'ECDH', namedCurve: 'P-256' },
        true,
        ['deriveKey', 'deriveBits']
    );
    return keyPair;
}

async function exportPublicKey(publicKey) {
    const exported = await crypto.subtle.exportKey('spki', publicKey);
    return toBase64(new Uint8Array(exported));
}

async function importPublicKey(base64Key) {
    const keyData = fromBase64(base64Key);
    return crypto.subtle.importKey(
        'spki',
        keyData,
        { name: 'ECDH', namedCurve: 'P-256' },
        false,
        []
    );
}

async function deriveSharedSecret(privateKey, otherPublicKey) {
    const sharedBits = await crypto.subtle.deriveBits(
        { name: 'ECDH', public: otherPublicKey },
        privateKey,
        256
    );
    return new Uint8Array(sharedBits);
}

async function initiateKeyExchange() {
    const receiver = document.getElementById('receiver').value.trim();
    if (!receiver) {
        showError('Please enter a recipient to exchange keys with.');
        return;
    }

    if (!stompClient || !stompClient.connected) {
        showError('Not connected to chat server.');
        return;
    }

    try {
        updateStatus('Initiating key exchange with ' + receiver + '...', true);

        const keyPair = await generateECDHKeyPair();
        const publicKeyBase64 = await exportPublicKey(keyPair.publicKey);

        pendingKeyExchanges.set(receiver, {
            privateKey: keyPair.privateKey,
            timestamp: Date.now()
        });

        stompClient.send("/app/key-exchange", { username: (currentUsername || currentUserId) }, JSON.stringify({
            sender: currentUsername || currentUserId,
            receiver: receiver,
            publicKey: publicKeyBase64,
            type: 'KEY_OFFER'
        }));

        hideError();
        updateStatus('Key exchange request sent to ' + receiver + '. Waiting for response...', true);
    } catch (error) {
        console.error('Error initiating key exchange:', error);
        showError('Failed to initiate key exchange: ' + error.message);
    }
}

async function handleKeyExchangeMessage(msg) {
    const { sender, publicKey, type } = msg;

    console.log('Received key exchange message:', type, 'from', sender);

    if (type === 'KEY_OFFER') {
        try {
            const keyPair = await generateECDHKeyPair();
            const ourPublicKeyBase64 = await exportPublicKey(keyPair.publicKey);

            const theirPublicKey = await importPublicKey(publicKey);
            const sharedSecret = await deriveSharedSecret(keyPair.privateKey, theirPublicKey);
            const sharedKeyBase64 = toBase64(sharedSecret);

            setSharedKey(sender, sharedKeyBase64);

            const passphraseEl = document.getElementById('passphrase');
            if (passphraseEl) {
                passphraseEl.value = sharedKeyBase64;
            }
            localStorage.setItem(AUTO_KEY_STORAGE, sharedKeyBase64);

            stompClient.send("/app/key-exchange", { username: (currentUsername || currentUserId) }, JSON.stringify({
                sender: currentUsername || currentUserId,
                receiver: sender,
                publicKey: ourPublicKeyBase64,
                type: 'KEY_RESPONSE'
            }));

            updateStatus('Key exchanged with ' + sender + '! You can now chat securely.', true);
            showKeyExchangeNotification(sender, 'accepted');
        } catch (error) {
            console.error('Error handling key offer:', error);
            showError('Failed to process key exchange from ' + sender);
        }
    } else if (type === 'KEY_RESPONSE') {
        const pending = pendingKeyExchanges.get(sender);
        if (!pending) {
            console.warn('Received key response but no pending exchange for', sender);
            return;
        }

        try {
            const theirPublicKey = await importPublicKey(publicKey);
            const sharedSecret = await deriveSharedSecret(pending.privateKey, theirPublicKey);
            const sharedKeyBase64 = toBase64(sharedSecret);

            setSharedKey(sender, sharedKeyBase64);

            const passphraseEl = document.getElementById('passphrase');
            if (passphraseEl) {
                passphraseEl.value = sharedKeyBase64;
            }
            localStorage.setItem(AUTO_KEY_STORAGE, sharedKeyBase64);

            pendingKeyExchanges.delete(sender);

            updateStatus('Key exchange completed with ' + sender + '! You can now chat securely.', true);
            showKeyExchangeNotification(sender, 'completed');
        } catch (error) {
            console.error('Error handling key response:', error);
            showError('Failed to complete key exchange with ' + sender);
            pendingKeyExchanges.delete(sender);
        }
    }
}

function showKeyExchangeNotification(otherUser, status) {
    const messagesDiv = document.getElementById('messages');
    const notifDiv = document.createElement('div');
    notifDiv.style.cssText = 'text-align:center; padding:10px; margin:10px 0; background:#d4edda; border-radius:4px; color:#155724; font-size:13px;';

    if (status === 'accepted') {
        notifDiv.textContent = 'Key exchange with ' + otherUser + ' accepted. Secure channel established!';
    } else if (status === 'completed') {
        notifDiv.textContent = 'Key exchange with ' + otherUser + ' completed. Secure channel established!';
    }

    messagesDiv.appendChild(notifDiv);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function useSharedKeyForUser() {
    const receiver = document.getElementById('receiver').value.trim();
    if (!receiver) {
        showError('Please enter a recipient first.');
        return;
    }

    const sharedKey = getSharedKeyForUser(receiver);
    if (sharedKey) {
        const passphraseEl = document.getElementById('passphrase');
        if (passphraseEl) {
            passphraseEl.value = sharedKey;
        }
        localStorage.setItem(AUTO_KEY_STORAGE, sharedKey);
        hideError();
        updateStatus('Using shared key for ' + receiver, true);
    } else {
        showError('No shared key found for ' + receiver + '. Initiate a key exchange first.');
    }
}

function listSharedKeys() {
    const keys = getSharedKeys();
    const users = Object.keys(keys);
    if (users.length === 0) {
        updateStatus('No shared keys stored.', true);
        return;
    }
    console.log('Shared keys with users:', users);
    updateStatus('Shared keys with: ' + users.join(', '), true);
}
