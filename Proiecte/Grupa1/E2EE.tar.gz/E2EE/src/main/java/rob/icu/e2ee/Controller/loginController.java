
package rob.icu.e2ee.Controller;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import rob.icu.e2ee.Services.userService;
import rob.icu.e2ee.entities.User;

import java.util.ArrayList;
import java.util.Map;

@RestController
@RequestMapping("/api/login")
public class loginController {
    private userService userService;
    public loginController(userService userService) {
        this.userService = userService;
    }
    private final SecurityContextRepository securityContextRepository= new HttpSessionSecurityContextRepository();


    @PostMapping
    public ResponseEntity<?> login(@RequestBody Map<String, String> body,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {
        String username = body.get("name");
        String password = body.get("password");

        boolean isAuthenticated = userService.checkUser(username, password);

        if (isAuthenticated) {

            UsernamePasswordAuthenticationToken authToken =
                    new UsernamePasswordAuthenticationToken(username, password, new ArrayList<>());


            SecurityContext context = SecurityContextHolder.createEmptyContext();
            context.setAuthentication(authToken);
            SecurityContextHolder.setContext(context);

            securityContextRepository.saveContext(context, request, response);


            User user = userService.getUserByName(username);
            if (user != null) {

                Cookie userIdCookie = new Cookie("userId", user.getId());
                userIdCookie.setPath("/");
                userIdCookie.setMaxAge(24 * 60 * 60);
                response.addCookie(userIdCookie);

                Cookie usernameCookie = new Cookie("username", user.getName());
                usernameCookie.setPath("/");
                usernameCookie.setMaxAge(24 * 60 * 60);
                response.addCookie(usernameCookie);
            }

            return ResponseEntity.ok(Map.of(
                    "message", "Login successful",
                    "username", username
            ));
        } else {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid credentials"));
        }
    }
}