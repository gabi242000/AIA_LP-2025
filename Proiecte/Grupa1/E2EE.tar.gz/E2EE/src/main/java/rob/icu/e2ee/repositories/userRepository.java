package rob.icu.e2ee.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import rob.icu.e2ee.entities.User;
import java.util.Optional;

public interface userRepository  extends MongoRepository <User,String>{
    Optional<User> findByName(String name);
}
