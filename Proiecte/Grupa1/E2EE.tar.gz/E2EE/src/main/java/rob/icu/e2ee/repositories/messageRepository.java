package rob.icu.e2ee.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import rob.icu.e2ee.entities.Message;
import rob.icu.e2ee.entities.User;

import java.util.Optional;
import java.util.List;

public interface messageRepository extends MongoRepository<Message,String> {
    List<Message> findBySenderAndReceiver(String sender, String receiver);
}
