package rob.icu.e2ee.Controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import rob.icu.e2ee.Services.userService;
import rob.icu.e2ee.entities.User;

@RestController
@RequestMapping("/api/users")
public class userController {

    private final userService userService;

    public userController( userService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        String password = body.get("password");

        if (name == null || password == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "name and password required"));
        }

        try {

            User saved = userService.createUser(name, password);
            return ResponseEntity.status(201).body(Map.of(
                    "name", saved.getName()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(409).body(Map.of("error", e.getMessage()));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "internal error"));
        }
    }

    @RequestMapping(value = "{id}")
    public ResponseEntity<?> getUserByID(@RequestParam Map<String, String> body, @PathVariable String id) {
        String name = body.get("name");
        try{
            User saved = userService.getUser(id);
            return ResponseEntity.status(201).body(Map.of(
                    "name", saved.getName()
            ));
        }catch (Exception e){
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
