package rob.icu.e2ee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E2EeApplication {

    public static void main(String[] args) {
        SpringApplication.run(E2EeApplication.class, args);
    }
}
