
package rob.icu.e2ee.Controller;

import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import rob.icu.e2ee.entities.Message;
import rob.icu.e2ee.repositories.messageRepository;
import java.util.List;
import java.util.Map;

@Controller
public class chatController {
    private final SimpMessagingTemplate messagingTemplate;
    private final messageRepository messageRepository;

    public chatController(SimpMessagingTemplate messagingTemplate, messageRepository messageRepository) {
        this.messagingTemplate = messagingTemplate;
        this.messageRepository = messageRepository;
    }

    @MessageMapping("/private-message")
    public void sendPrivateMessage(Message message, @Headers Map<String, Object> headers) {

        try {
            Object nativeHeadersObj = headers != null ? headers.get("nativeHeaders") : null;
            if (nativeHeadersObj instanceof Map<?, ?> nativeHeaders) {
                Object usernameHeader = nativeHeaders.get("username");
                String usernameFromHeader = null;
                if (usernameHeader instanceof List<?> list && !list.isEmpty()) {
                    Object first = list.get(0);
                    if (first != null) usernameFromHeader = first.toString();
                } else if (usernameHeader != null) {
                    usernameFromHeader = usernameHeader.toString();
                }
                if (usernameFromHeader != null && !usernameFromHeader.isEmpty()) {
                    message.setSender(usernameFromHeader);
                }
            }
        } catch (Exception ignored) {

        }

        try {
            messageRepository.save(message);
        } catch (Exception e) {

            System.err.println("Failed to save message: " + e.getMessage());
        }

        String destination = "/topic/messages." + message.getReceiver();
        messagingTemplate.convertAndSend(destination, message);
    }

    @MessageMapping("/key-exchange")
    public void handleKeyExchange(Map<String, Object> keyExchangeMessage, @Headers Map<String, Object> headers) {

        try {
            Object nativeHeadersObj = headers != null ? headers.get("nativeHeaders") : null;
            if (nativeHeadersObj instanceof Map<?, ?> nativeHeaders) {
                Object usernameHeader = nativeHeaders.get("username");
                String usernameFromHeader = null;
                if (usernameHeader instanceof List<?> list && !list.isEmpty()) {
                    Object first = list.get(0);
                    if (first != null) usernameFromHeader = first.toString();
                } else if (usernameHeader != null) {
                    usernameFromHeader = usernameHeader.toString();
                }
                if (usernameFromHeader != null && !usernameFromHeader.isEmpty()) {
                    keyExchangeMessage.put("sender", usernameFromHeader);
                }
            }
        } catch (Exception ignored) {
        }


        Object receiver = keyExchangeMessage.get("receiver");
        if (receiver != null) {
            String destination = "/topic/key-exchange." + receiver.toString();
            messagingTemplate.convertAndSend(destination, keyExchangeMessage);
        }
    }
}