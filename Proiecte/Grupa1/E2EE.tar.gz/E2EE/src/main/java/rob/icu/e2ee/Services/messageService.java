package rob.icu.e2ee.Services;

import org.springframework.stereotype.Service;
import rob.icu.e2ee.entities.Message;
import rob.icu.e2ee.repositories.messageRepository;

import java.util.List;


@Service
public class messageService {

    private final messageRepository MessageRepository;

    public messageService(messageRepository MessageRepository) {
        this.MessageRepository = MessageRepository;
    }

    public void saveMessage(Message message) {
        MessageRepository.save(message);}
}
