package rob.icu.e2ee.Controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import rob.icu.e2ee.entities.Message;
import rob.icu.e2ee.repositories.messageRepository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class messageController {

    private final messageRepository messageRepository;

    @Autowired
    public messageController(messageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    @GetMapping("/conversation")
    public ResponseEntity<List<Message>> getConversation(
            @RequestParam("with") String withIdentifier,
            @CookieValue(value = "username", required = false) String myUsername,
            @CookieValue(value = "userId", required = false) String myUserId
    ) {
        if (withIdentifier == null || withIdentifier.isBlank()) {
            return ResponseEntity.badRequest().build();
        }

        List<Message> all = new ArrayList<>();

        if (myUsername != null && !myUsername.isBlank()) {
            all.addAll(messageRepository.findBySenderAndReceiver(myUsername, withIdentifier));
        }
        if (myUserId != null && !myUserId.isBlank() && (myUsername == null || !myUserId.equals(myUsername))) {
            all.addAll(messageRepository.findBySenderAndReceiver(myUserId, withIdentifier));
        }

        if (myUsername != null && !myUsername.isBlank()) {
            all.addAll(messageRepository.findBySenderAndReceiver(withIdentifier, myUsername));
        }
        if (myUserId != null && !myUserId.isBlank()) {
            all.addAll(messageRepository.findBySenderAndReceiver(withIdentifier, myUserId));
        }

        all.sort(Comparator.comparing(m -> m.getId() == null ? "" : m.getId()));

        return ResponseEntity.ok(all);
    }
}
