package rob.icu.e2ee.Services;

import rob.icu.e2ee.entities.User;
import rob.icu.e2ee.repositories.userRepository;
import org.springframework.stereotype.Service;

@Service
public class userService {

        private final userRepository userRepository;

        public userService(userRepository userRepository) {
            this.userRepository = userRepository;
        }

        public User createUser(String name, String password) {

            if (userRepository.findByName(name).isPresent()) {
                throw new IllegalArgumentException("User already exists");
            }

            User user = new User(name, password);
            return userRepository.save(user);
        }

        public User getUser(String id) {
            if(userRepository.findById(id).isPresent()) {
                return userRepository.findById(id).get();
            }else{
                throw new IllegalArgumentException("User does not exist");
            }
        }
        public User getUserByName(String name) {
            if(userRepository.findByName(name).isPresent()) {
                return userRepository.findByName(name).get();
            }else{
                throw new IllegalArgumentException("User does not exist");
            }
        }

        public boolean checkUser(String name, String password) {
            User user = userRepository.findByName(name).orElseThrow(() -> new IllegalArgumentException("User does not exist"));
            if(!user.getPassword().equals(password)) {
                throw new IllegalArgumentException("Invalid password");
            }
            return true;
        }


}
